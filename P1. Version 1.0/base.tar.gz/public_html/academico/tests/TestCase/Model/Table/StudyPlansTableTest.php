<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\StudyPlansTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\StudyPlansTable Test Case
 */
class StudyPlansTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\StudyPlansTable
     */
    protected $StudyPlans;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.StudyPlans',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('StudyPlans') ? [] : ['className' => StudyPlansTable::class];
        $this->StudyPlans = TableRegistry::getTableLocator()->get('StudyPlans', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->StudyPlans);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
