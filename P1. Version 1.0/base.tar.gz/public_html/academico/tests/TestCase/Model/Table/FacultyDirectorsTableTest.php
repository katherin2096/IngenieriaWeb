<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\FacultyDirectorsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\FacultyDirectorsTable Test Case
 */
class FacultyDirectorsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\FacultyDirectorsTable
     */
    protected $FacultyDirectors;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.FacultyDirectors',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('FacultyDirectors') ? [] : ['className' => FacultyDirectorsTable::class];
        $this->FacultyDirectors = TableRegistry::getTableLocator()->get('FacultyDirectors', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->FacultyDirectors);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
