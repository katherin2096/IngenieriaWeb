<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\SchoolDirectorsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\SchoolDirectorsTable Test Case
 */
class SchoolDirectorsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\SchoolDirectorsTable
     */
    protected $SchoolDirectors;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.SchoolDirectors',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('SchoolDirectors') ? [] : ['className' => SchoolDirectorsTable::class];
        $this->SchoolDirectors = TableRegistry::getTableLocator()->get('SchoolDirectors', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->SchoolDirectors);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
