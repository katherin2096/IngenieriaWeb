<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\SchoolCoordinatorsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\SchoolCoordinatorsTable Test Case
 */
class SchoolCoordinatorsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\SchoolCoordinatorsTable
     */
    protected $SchoolCoordinators;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.SchoolCoordinators',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('SchoolCoordinators') ? [] : ['className' => SchoolCoordinatorsTable::class];
        $this->SchoolCoordinators = TableRegistry::getTableLocator()->get('SchoolCoordinators', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->SchoolCoordinators);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
