<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * TeachersFixture
 */
class TeachersFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_teacher' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'codigo docente', 'autoIncrement' => true, 'precision' => null],
        'dni_teacher' => ['type' => 'integer', 'length' => 8, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar numero de dni', 'precision' => null, 'autoIncrement' => null],
        'id_type_contract' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'tipo de contrato', 'precision' => null, 'autoIncrement' => null],
        'name_teacher' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar nombre de Docente', 'precision' => null],
        'lastname_teacher' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar apellidos de Docente', 'precision' => null],
        'email_teacher' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar email de Docente', 'precision' => null],
        'phone_teacher' => ['type' => 'string', 'length' => 15, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar celular de Docente, porfavor omita el codigo de pais', 'precision' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        '_indexes' => [
            'contact_key' => ['type' => 'index', 'columns' => ['id_type_contract'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_teacher'], 'length' => []],
            'teachers_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_type_contract'], 'references' => ['type_contracts', 'id_type_contract'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_teacher' => 1,
                'dni_teacher' => 1,
                'id_type_contract' => 1,
                'name_teacher' => 'Lorem ipsum dolor sit amet',
                'lastname_teacher' => 'Lorem ipsum dolor sit amet',
                'email_teacher' => 'Lorem ipsum dolor sit amet',
                'phone_teacher' => 'Lorem ipsum d',
                'estate' => 1,
                'created' => '2020-05-10 04:08:24',
                'modified' => '2020-05-10 04:08:24',
            ],
        ];
        parent::init();
    }
}
