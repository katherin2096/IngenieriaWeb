<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * RectorsFixture
 */
class RectorsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_rector' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'codigo de rector', 'autoIncrement' => true, 'precision' => null],
        'dni_rector' => ['type' => 'integer', 'length' => 8, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar numero de dni', 'precision' => null, 'autoIncrement' => null],
        'id_university' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id (RUC) de universidad', 'precision' => null, 'autoIncrement' => null],
        'name_rector' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar nombre de Rector', 'precision' => null],
        'lastname_rector' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar apellidos de Rector', 'precision' => null],
        'email_rector' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar email de Rector', 'precision' => null],
        'phone_rector' => ['type' => 'string', 'length' => 15, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar celular de Rector, porfavor omita el codigo de pais', 'precision' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        '_indexes' => [
            'university_key' => ['type' => 'index', 'columns' => ['id_university'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_rector'], 'length' => []],
            'rectors_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_university'], 'references' => ['universitys', 'id_university'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_rector' => 1,
                'dni_rector' => 1,
                'id_university' => 1,
                'name_rector' => 'Lorem ipsum dolor sit amet',
                'lastname_rector' => 'Lorem ipsum dolor sit amet',
                'email_rector' => 'Lorem ipsum dolor sit amet',
                'phone_rector' => 'Lorem ipsum d',
                'estate' => 1,
                'created' => '2020-05-10 03:58:42',
                'modified' => '2020-05-10 03:58:42',
            ],
        ];
        parent::init();
    }
}
