<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * StudyPlansFixture
 */
class StudyPlansFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_study_plan' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de plan de estudio', 'autoIncrement' => true, 'precision' => null],
        'id_academic' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de de periodo academico', 'precision' => null, 'autoIncrement' => null],
        'name' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar codigo de semestre ejemplo 2020-1', 'precision' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '0', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        '_indexes' => [
            'academic_key' => ['type' => 'index', 'columns' => ['id_academic'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_study_plan'], 'length' => []],
            'study_plans_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_academic'], 'references' => ['academics', 'id_academic'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_study_plan' => 1,
                'id_academic' => 1,
                'name' => 'Lorem ipsum dolor sit amet',
                'estate' => 1,
                'created' => '2020-05-10 04:06:15',
                'modified' => '2020-05-10 04:06:15',
            ],
        ];
        parent::init();
    }
}
