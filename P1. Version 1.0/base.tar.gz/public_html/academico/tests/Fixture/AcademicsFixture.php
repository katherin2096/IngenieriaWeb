<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AcademicsFixture
 */
class AcademicsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_academic' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de periodo academico', 'autoIncrement' => true, 'precision' => null],
        'id_school' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de escuela', 'precision' => null, 'autoIncrement' => null],
        'id_school_director' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar numero de dni del director en curso', 'precision' => null, 'autoIncrement' => null],
        'id_school_coordinator' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar numero de dni del coordinador en curso', 'precision' => null, 'autoIncrement' => null],
        'name' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar codigo de semestre ejemplo 2020-1', 'precision' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '0', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        '_indexes' => [
            'school_key' => ['type' => 'index', 'columns' => ['id_school'], 'length' => []],
            'director_key' => ['type' => 'index', 'columns' => ['id_school_director'], 'length' => []],
            'cordinator_key' => ['type' => 'index', 'columns' => ['id_school_coordinator'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_academic'], 'length' => []],
            'academics_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_school'], 'references' => ['schools', 'id_school'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'academics_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_school_director'], 'references' => ['school_directors', 'id_school_director'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'academics_ibfk_3' => ['type' => 'foreign', 'columns' => ['id_school_coordinator'], 'references' => ['school_coordinators', 'id_school_coordinator'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_academic' => 1,
                'id_school' => 1,
                'id_school_director' => 1,
                'id_school_coordinator' => 1,
                'name' => 'Lorem ipsum dolor sit amet',
                'estate' => 1,
                'created' => '2020-05-10 04:06:00',
                'modified' => '2020-05-10 04:06:00',
            ],
        ];
        parent::init();
    }
}
