<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * SchoolDirectorsFixture
 */
class SchoolDirectorsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_school_director' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo director', 'autoIncrement' => true, 'precision' => null],
        'dni_school_director' => ['type' => 'integer', 'length' => 8, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar numero de dni', 'precision' => null, 'autoIncrement' => null],
        'id_school' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'name_school_director' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar nombre de director de escuela', 'precision' => null],
        'lastname_school_director' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar apellidos de director de escuela', 'precision' => null],
        'email_school_director' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar email de director de escuela', 'precision' => null],
        'phone_school_director' => ['type' => 'string', 'length' => 15, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar celular de director de escuela, porfavor omita el codigo de pais', 'precision' => null],
        'estate_school_director' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        '_indexes' => [
            'school_key' => ['type' => 'index', 'columns' => ['id_school'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_school_director'], 'length' => []],
            'school_directors_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_school'], 'references' => ['schools', 'id_school'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_school_director' => 1,
                'dni_school_director' => 1,
                'id_school' => 1,
                'name_school_director' => 'Lorem ipsum dolor sit amet',
                'lastname_school_director' => 'Lorem ipsum dolor sit amet',
                'email_school_director' => 'Lorem ipsum dolor sit amet',
                'phone_school_director' => 'Lorem ipsum d',
                'estate_school_director' => 1,
                'created' => '2020-05-10 04:04:47',
                'modified' => '2020-05-10 04:04:47',
            ],
        ];
        parent::init();
    }
}
