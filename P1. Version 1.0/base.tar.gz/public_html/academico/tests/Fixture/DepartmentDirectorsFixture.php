<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DepartmentDirectorsFixture
 */
class DepartmentDirectorsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_department_director' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo director de departmento', 'autoIncrement' => true, 'precision' => null],
        'dni_department_director' => ['type' => 'integer', 'length' => 8, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar numero de dni', 'precision' => null, 'autoIncrement' => null],
        'id_department' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'name_department_director' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar nombre de director de departmento', 'precision' => null],
        'lastname_department_director' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar apellidos de director de departmento', 'precision' => null],
        'email_department_director' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar email de director de departmento', 'precision' => null],
        'phone_department_director' => ['type' => 'string', 'length' => 15, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar celular de director de departmento, porfavor omita el codigo de pais', 'precision' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        '_indexes' => [
            'department_key' => ['type' => 'index', 'columns' => ['id_department'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_department_director'], 'length' => []],
            'department_directors_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_department'], 'references' => ['departments', 'id_department'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_department_director' => 1,
                'dni_department_director' => 1,
                'id_department' => 1,
                'name_department_director' => 'Lorem ipsum dolor sit amet',
                'lastname_department_director' => 'Lorem ipsum dolor sit amet',
                'email_department_director' => 'Lorem ipsum dolor sit amet',
                'phone_department_director' => 'Lorem ipsum d',
                'estate' => 1,
                'created' => '2020-05-10 04:44:01',
                'modified' => '2020-05-10 04:44:01',
            ],
        ];
        parent::init();
    }
}
