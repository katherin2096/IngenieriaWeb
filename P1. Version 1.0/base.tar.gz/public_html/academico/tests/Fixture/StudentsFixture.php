<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * StudentsFixture
 */
class StudentsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // phpcs:disable
    public $fields = [
        'id_student' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id estudiante', 'autoIncrement' => true, 'precision' => null],
        'dni_student' => ['type' => 'integer', 'length' => 8, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'dni de estudiante', 'precision' => null, 'autoIncrement' => null],
        'id_school' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'name_student' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar nombre de estudiante', 'precision' => null],
        'lastname_student' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar apellidos de estudiante', 'precision' => null],
        'email_student' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar email de estudiante', 'precision' => null],
        'phone_student' => ['type' => 'string', 'length' => 15, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar celular de estudiante, porfavor omita el codigo de pais', 'precision' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        'modified' => ['type' => 'datetime', 'length' => null, 'precision' => null, 'null' => true, 'default' => null, 'comment' => ''],
        '_indexes' => [
            'school_key' => ['type' => 'index', 'columns' => ['id_school'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_student'], 'length' => []],
            'students_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_school'], 'references' => ['schools', 'id_school'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // phpcs:enable
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id_student' => 1,
                'dni_student' => 1,
                'id_school' => 1,
                'name_student' => 'Lorem ipsum dolor sit amet',
                'lastname_student' => 'Lorem ipsum dolor sit amet',
                'email_student' => 'Lorem ipsum dolor sit amet',
                'phone_student' => 'Lorem ipsum d',
                'estate' => 1,
                'created' => '2020-05-10 04:08:57',
                'modified' => '2020-05-10 04:08:57',
            ],
        ];
        parent::init();
    }
}
