<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Students Model
 *
 * @method \App\Model\Entity\Student newEmptyEntity()
 * @method \App\Model\Entity\Student newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Student[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Student get($primaryKey, $options = [])
 * @method \App\Model\Entity\Student findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Student patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Student[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Student|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Student saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Student[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Student[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Student[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Student[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class StudentsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('students');
        $this->setDisplayField('id_student');
        $this->setPrimaryKey('id_student');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_student')
            ->allowEmptyString('id_student', null, 'create');

        $validator
            ->integer('dni_student')
            ->allowEmptyString('dni_student');

        $validator
            ->integer('id_school')
            ->requirePresence('id_school', 'create')
            ->notEmptyString('id_school');

        $validator
            ->scalar('name_student')
            ->maxLength('name_student', 255)
            ->requirePresence('name_student', 'create')
            ->notEmptyString('name_student');

        $validator
            ->scalar('lastname_student')
            ->maxLength('lastname_student', 255)
            ->requirePresence('lastname_student', 'create')
            ->notEmptyString('lastname_student');

        $validator
            ->scalar('email_student')
            ->maxLength('email_student', 255)
            ->requirePresence('email_student', 'create')
            ->notEmptyString('email_student');

        $validator
            ->scalar('phone_student')
            ->maxLength('phone_student', 15)
            ->requirePresence('phone_student', 'create')
            ->notEmptyString('phone_student');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
