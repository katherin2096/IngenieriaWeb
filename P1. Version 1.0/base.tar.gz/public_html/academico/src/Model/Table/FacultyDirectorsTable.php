<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * FacultyDirectors Model
 *
 * @method \App\Model\Entity\FacultyDirector newEmptyEntity()
 * @method \App\Model\Entity\FacultyDirector newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\FacultyDirector[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\FacultyDirector get($primaryKey, $options = [])
 * @method \App\Model\Entity\FacultyDirector findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\FacultyDirector patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\FacultyDirector[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\FacultyDirector|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\FacultyDirector saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\FacultyDirector[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\FacultyDirector[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\FacultyDirector[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\FacultyDirector[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class FacultyDirectorsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('faculty_directors');
        $this->setDisplayField('id_faculty_director');
        $this->setPrimaryKey('id_faculty_director');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_faculty_director')
            ->allowEmptyString('id_faculty_director', null, 'create');

        $validator
            ->integer('dni_faculty_director')
            ->requirePresence('dni_faculty_director', 'create')
            ->notEmptyString('dni_faculty_director');

        $validator
            ->integer('id_faculty')
            ->requirePresence('id_faculty', 'create')
            ->notEmptyString('id_faculty');

        $validator
            ->scalar('name_faculty_director')
            ->maxLength('name_faculty_director', 255)
            ->requirePresence('name_faculty_director', 'create')
            ->notEmptyString('name_faculty_director');

        $validator
            ->scalar('lastname_faculty_director')
            ->maxLength('lastname_faculty_director', 255)
            ->requirePresence('lastname_faculty_director', 'create')
            ->notEmptyString('lastname_faculty_director');

        $validator
            ->scalar('email_faculty_director')
            ->maxLength('email_faculty_director', 255)
            ->requirePresence('email_faculty_director', 'create')
            ->notEmptyString('email_faculty_director');

        $validator
            ->scalar('phone_faculty_director')
            ->maxLength('phone_faculty_director', 15)
            ->requirePresence('phone_faculty_director', 'create')
            ->notEmptyString('phone_faculty_director');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
