<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Rectors Model
 *
 * @method \App\Model\Entity\Rector newEmptyEntity()
 * @method \App\Model\Entity\Rector newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Rector[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Rector get($primaryKey, $options = [])
 * @method \App\Model\Entity\Rector findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Rector patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Rector[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Rector|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Rector saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Rector[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Rector[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Rector[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Rector[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class RectorsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('rectors');
        $this->setDisplayField('id_rector');
        $this->setPrimaryKey('id_rector');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_rector')
            ->allowEmptyString('id_rector', null, 'create');

        $validator
            ->integer('dni_rector')
            ->requirePresence('dni_rector', 'create')
            ->notEmptyString('dni_rector');

        $validator
            ->integer('id_university')
            ->requirePresence('id_university', 'create')
            ->notEmptyString('id_university');

        $validator
            ->scalar('name_rector')
            ->maxLength('name_rector', 255)
            ->requirePresence('name_rector', 'create')
            ->notEmptyString('name_rector');

        $validator
            ->scalar('lastname_rector')
            ->maxLength('lastname_rector', 255)
            ->requirePresence('lastname_rector', 'create')
            ->notEmptyString('lastname_rector');

        $validator
            ->scalar('email_rector')
            ->maxLength('email_rector', 255)
            ->requirePresence('email_rector', 'create')
            ->notEmptyString('email_rector');

        $validator
            ->scalar('phone_rector')
            ->maxLength('phone_rector', 15)
            ->requirePresence('phone_rector', 'create')
            ->notEmptyString('phone_rector');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
