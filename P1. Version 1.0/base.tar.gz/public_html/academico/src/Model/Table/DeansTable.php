<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Deans Model
 *
 * @method \App\Model\Entity\Dean newEmptyEntity()
 * @method \App\Model\Entity\Dean newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\Dean[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Dean get($primaryKey, $options = [])
 * @method \App\Model\Entity\Dean findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\Dean patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Dean[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Dean|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Dean saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Dean[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Dean[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\Dean[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\Dean[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class DeansTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('deans');
        $this->setDisplayField('id_dean');
        $this->setPrimaryKey('id_dean');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_dean')
            ->allowEmptyString('id_dean', null, 'create');

        $validator
            ->integer('dni_dean')
            ->requirePresence('dni_dean', 'create')
            ->notEmptyString('dni_dean');

        $validator
            ->integer('id_faculty')
            ->requirePresence('id_faculty', 'create')
            ->notEmptyString('id_faculty');

        $validator
            ->scalar('name_dean')
            ->maxLength('name_dean', 255)
            ->requirePresence('name_dean', 'create')
            ->notEmptyString('name_dean');

        $validator
            ->scalar('lastname_dean')
            ->maxLength('lastname_dean', 255)
            ->requirePresence('lastname_dean', 'create')
            ->notEmptyString('lastname_dean');

        $validator
            ->scalar('email_dean')
            ->maxLength('email_dean', 255)
            ->requirePresence('email_dean', 'create')
            ->notEmptyString('email_dean');

        $validator
            ->scalar('phone_dean')
            ->maxLength('phone_dean', 15)
            ->requirePresence('phone_dean', 'create')
            ->notEmptyString('phone_dean');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
