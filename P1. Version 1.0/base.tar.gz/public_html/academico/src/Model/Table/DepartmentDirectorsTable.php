<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * DepartmentDirectors Model
 *
 * @method \App\Model\Entity\DepartmentDirector newEmptyEntity()
 * @method \App\Model\Entity\DepartmentDirector newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\DepartmentDirector[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\DepartmentDirector get($primaryKey, $options = [])
 * @method \App\Model\Entity\DepartmentDirector findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\DepartmentDirector patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\DepartmentDirector[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\DepartmentDirector|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\DepartmentDirector saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\DepartmentDirector[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\DepartmentDirector[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\DepartmentDirector[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\DepartmentDirector[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class DepartmentDirectorsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('department_directors');
        $this->setDisplayField('id_department_director');
        $this->setPrimaryKey('id_department_director');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_department_director')
            ->allowEmptyString('id_department_director', null, 'create');

        $validator
            ->integer('dni_department_director')
            ->requirePresence('dni_department_director', 'create')
            ->notEmptyString('dni_department_director');

        $validator
            ->integer('id_department')
            ->requirePresence('id_department', 'create')
            ->notEmptyString('id_department');

        $validator
            ->scalar('name_department_director')
            ->maxLength('name_department_director', 255)
            ->requirePresence('name_department_director', 'create')
            ->notEmptyString('name_department_director');

        $validator
            ->scalar('lastname_department_director')
            ->maxLength('lastname_department_director', 255)
            ->requirePresence('lastname_department_director', 'create')
            ->notEmptyString('lastname_department_director');

        $validator
            ->scalar('email_department_director')
            ->maxLength('email_department_director', 255)
            ->requirePresence('email_department_director', 'create')
            ->notEmptyString('email_department_director');

        $validator
            ->scalar('phone_department_director')
            ->maxLength('phone_department_director', 15)
            ->requirePresence('phone_department_director', 'create')
            ->notEmptyString('phone_department_director');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
