<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * SchoolCoordinators Model
 *
 * @method \App\Model\Entity\SchoolCoordinator newEmptyEntity()
 * @method \App\Model\Entity\SchoolCoordinator newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\SchoolCoordinator[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SchoolCoordinator get($primaryKey, $options = [])
 * @method \App\Model\Entity\SchoolCoordinator findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\SchoolCoordinator patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SchoolCoordinator[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\SchoolCoordinator|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SchoolCoordinator saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SchoolCoordinator[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\SchoolCoordinator[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\SchoolCoordinator[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\SchoolCoordinator[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SchoolCoordinatorsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('school_coordinators');
        $this->setDisplayField('id_school_coordinator');
        $this->setPrimaryKey('id_school_coordinator');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_school_coordinator')
            ->allowEmptyString('id_school_coordinator', null, 'create');

        $validator
            ->integer('dni_school_coordinator')
            ->requirePresence('dni_school_coordinator', 'create')
            ->notEmptyString('dni_school_coordinator');

        $validator
            ->integer('id_school')
            ->requirePresence('id_school', 'create')
            ->notEmptyString('id_school');

        $validator
            ->scalar('name_school_coordinator')
            ->maxLength('name_school_coordinator', 255)
            ->requirePresence('name_school_coordinator', 'create')
            ->notEmptyString('name_school_coordinator');

        $validator
            ->scalar('lastname_school_coordinator')
            ->maxLength('lastname_school_coordinator', 255)
            ->requirePresence('lastname_school_coordinator', 'create')
            ->notEmptyString('lastname_school_coordinator');

        $validator
            ->scalar('email_school_coordinator')
            ->maxLength('email_school_coordinator', 255)
            ->requirePresence('email_school_coordinator', 'create')
            ->notEmptyString('email_school_coordinator');

        $validator
            ->scalar('phone_school_coordinator')
            ->maxLength('phone_school_coordinator', 15)
            ->requirePresence('phone_school_coordinator', 'create')
            ->notEmptyString('phone_school_coordinator');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
