<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * TypeContracts Model
 *
 * @method \App\Model\Entity\TypeContract newEmptyEntity()
 * @method \App\Model\Entity\TypeContract newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\TypeContract[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\TypeContract get($primaryKey, $options = [])
 * @method \App\Model\Entity\TypeContract findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\TypeContract patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\TypeContract[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\TypeContract|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TypeContract saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\TypeContract[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\TypeContract[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\TypeContract[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\TypeContract[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class TypeContractsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('type_contracts');
        $this->setDisplayField('id_type_contract');
        $this->setPrimaryKey('id_type_contract');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_type_contract')
            ->allowEmptyString('id_type_contract', null, 'create');

        $validator
            ->scalar('name_type_contract')
            ->maxLength('name_type_contract', 255)
            ->requirePresence('name_type_contract', 'create')
            ->notEmptyString('name_type_contract');

        return $validator;
    }
}
