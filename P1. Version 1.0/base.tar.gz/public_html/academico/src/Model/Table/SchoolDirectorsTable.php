<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * SchoolDirectors Model
 *
 * @method \App\Model\Entity\SchoolDirector newEmptyEntity()
 * @method \App\Model\Entity\SchoolDirector newEntity(array $data, array $options = [])
 * @method \App\Model\Entity\SchoolDirector[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SchoolDirector get($primaryKey, $options = [])
 * @method \App\Model\Entity\SchoolDirector findOrCreate($search, ?callable $callback = null, $options = [])
 * @method \App\Model\Entity\SchoolDirector patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SchoolDirector[] patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\SchoolDirector|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SchoolDirector saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SchoolDirector[]|\Cake\Datasource\ResultSetInterface|false saveMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\SchoolDirector[]|\Cake\Datasource\ResultSetInterface saveManyOrFail(iterable $entities, $options = [])
 * @method \App\Model\Entity\SchoolDirector[]|\Cake\Datasource\ResultSetInterface|false deleteMany(iterable $entities, $options = [])
 * @method \App\Model\Entity\SchoolDirector[]|\Cake\Datasource\ResultSetInterface deleteManyOrFail(iterable $entities, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SchoolDirectorsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('school_directors');
        $this->setDisplayField('id_school_director');
        $this->setPrimaryKey('id_school_director');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('id_school_director')
            ->allowEmptyString('id_school_director', null, 'create');

        $validator
            ->integer('dni_school_director')
            ->requirePresence('dni_school_director', 'create')
            ->notEmptyString('dni_school_director');

        $validator
            ->integer('id_school')
            ->requirePresence('id_school', 'create')
            ->notEmptyString('id_school');

        $validator
            ->scalar('name_school_director')
            ->maxLength('name_school_director', 255)
            ->requirePresence('name_school_director', 'create')
            ->notEmptyString('name_school_director');

        $validator
            ->scalar('lastname_school_director')
            ->maxLength('lastname_school_director', 255)
            ->requirePresence('lastname_school_director', 'create')
            ->notEmptyString('lastname_school_director');

        $validator
            ->scalar('email_school_director')
            ->maxLength('email_school_director', 255)
            ->requirePresence('email_school_director', 'create')
            ->notEmptyString('email_school_director');

        $validator
            ->scalar('phone_school_director')
            ->maxLength('phone_school_director', 15)
            ->requirePresence('phone_school_director', 'create')
            ->notEmptyString('phone_school_director');

        $validator
            ->boolean('estate_school_director')
            ->notEmptyString('estate_school_director');

        return $validator;
    }
}
