<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Academic Entity
 *
 * @property int $id_academic
 * @property int $id_school
 * @property int $id_school_director
 * @property int $id_school_coordinator
 * @property string $name
 * @property bool $estate
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 */
class Academic extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_school' => true,
        'id_school_director' => true,
        'id_school_coordinator' => true,
        'name' => true,
        'estate' => true,
        'created' => true,
        'modified' => true,
    ];
}
