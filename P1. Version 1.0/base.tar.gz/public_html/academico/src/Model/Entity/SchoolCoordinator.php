<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * SchoolCoordinator Entity
 *
 * @property int $id_school_coordinator
 * @property int $dni_school_coordinator
 * @property int $id_school
 * @property string $name_school_coordinator
 * @property string $lastname_school_coordinator
 * @property string $email_school_coordinator
 * @property string $phone_school_coordinator
 * @property bool $estate
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 */
class SchoolCoordinator extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'dni_school_coordinator' => true,
        'id_school' => true,
        'name_school_coordinator' => true,
        'lastname_school_coordinator' => true,
        'email_school_coordinator' => true,
        'phone_school_coordinator' => true,
        'estate' => true,
        'created' => true,
        'modified' => true,
    ];
}
