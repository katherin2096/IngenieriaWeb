<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Teacher Entity
 *
 * @property int $id_teacher
 * @property int $dni_teacher
 * @property int $id_type_contract
 * @property string $name_teacher
 * @property string $lastname_teacher
 * @property string $email_teacher
 * @property string $phone_teacher
 * @property bool $estate
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 */
class Teacher extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'dni_teacher' => true,
        'id_type_contract' => true,
        'name_teacher' => true,
        'lastname_teacher' => true,
        'email_teacher' => true,
        'phone_teacher' => true,
        'estate' => true,
        'created' => true,
        'modified' => true,
    ];
}
