<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * DepartmentDirector Entity
 *
 * @property int $id_department_director
 * @property int $dni_department_director
 * @property int $id_department
 * @property string $name_department_director
 * @property string $lastname_department_director
 * @property string $email_department_director
 * @property string $phone_department_director
 * @property bool $estate
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 */
class DepartmentDirector extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'dni_department_director' => true,
        'id_department' => true,
        'name_department_director' => true,
        'lastname_department_director' => true,
        'email_department_director' => true,
        'phone_department_director' => true,
        'estate' => true,
        'created' => true,
        'modified' => true,
    ];
}
