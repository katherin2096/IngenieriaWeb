<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * FacultyDirectors Controller
 *
 * @property \App\Model\Table\FacultyDirectorsTable $FacultyDirectors
 * @method \App\Model\Entity\FacultyDirector[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class FacultyDirectorsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $facultyDirectors = $this->paginate($this->FacultyDirectors);

        $this->set(compact('facultyDirectors'));
    }

    /**
     * View method
     *
     * @param string|null $id Faculty Director id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $facultyDirector = $this->FacultyDirectors->get($id, [
            'contain' => [],
        ]);

        $this->set('facultyDirector', $facultyDirector);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $facultyDirector = $this->FacultyDirectors->newEmptyEntity();
        if ($this->request->is('post')) {
            $facultyDirector = $this->FacultyDirectors->patchEntity($facultyDirector, $this->request->getData());
            if ($this->FacultyDirectors->save($facultyDirector)) {
                $this->Flash->success(__('The faculty director has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The faculty director could not be saved. Please, try again.'));
        }
        $this->set(compact('facultyDirector'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Faculty Director id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $facultyDirector = $this->FacultyDirectors->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $facultyDirector = $this->FacultyDirectors->patchEntity($facultyDirector, $this->request->getData());
            if ($this->FacultyDirectors->save($facultyDirector)) {
                $this->Flash->success(__('The faculty director has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The faculty director could not be saved. Please, try again.'));
        }
        $this->set(compact('facultyDirector'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Faculty Director id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $facultyDirector = $this->FacultyDirectors->get($id);
        if ($this->FacultyDirectors->delete($facultyDirector)) {
            $this->Flash->success(__('The faculty director has been deleted.'));
        } else {
            $this->Flash->error(__('The faculty director could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
