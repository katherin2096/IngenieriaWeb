<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * SchoolDirectors Controller
 *
 * @property \App\Model\Table\SchoolDirectorsTable $SchoolDirectors
 * @method \App\Model\Entity\SchoolDirector[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class SchoolDirectorsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $schoolDirectors = $this->paginate($this->SchoolDirectors);

        $this->set(compact('schoolDirectors'));
    }

    /**
     * View method
     *
     * @param string|null $id School Director id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $schoolDirector = $this->SchoolDirectors->get($id, [
            'contain' => [],
        ]);

        $this->set('schoolDirector', $schoolDirector);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $schoolDirector = $this->SchoolDirectors->newEmptyEntity();
        if ($this->request->is('post')) {
            $schoolDirector = $this->SchoolDirectors->patchEntity($schoolDirector, $this->request->getData());
            if ($this->SchoolDirectors->save($schoolDirector)) {
                $this->Flash->success(__('The school director has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The school director could not be saved. Please, try again.'));
        }
        $this->set(compact('schoolDirector'));
    }

    /**
     * Edit method
     *
     * @param string|null $id School Director id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $schoolDirector = $this->SchoolDirectors->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $schoolDirector = $this->SchoolDirectors->patchEntity($schoolDirector, $this->request->getData());
            if ($this->SchoolDirectors->save($schoolDirector)) {
                $this->Flash->success(__('The school director has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The school director could not be saved. Please, try again.'));
        }
        $this->set(compact('schoolDirector'));
    }

    /**
     * Delete method
     *
     * @param string|null $id School Director id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $schoolDirector = $this->SchoolDirectors->get($id);
        if ($this->SchoolDirectors->delete($schoolDirector)) {
            $this->Flash->success(__('The school director has been deleted.'));
        } else {
            $this->Flash->error(__('The school director could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
