<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Rectors Controller
 *
 * @property \App\Model\Table\RectorsTable $Rectors
 * @method \App\Model\Entity\Rector[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class RectorsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $rectors = $this->paginate($this->Rectors);

        $this->set(compact('rectors'));
    }

    /**
     * View method
     *
     * @param string|null $id Rector id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $rector = $this->Rectors->get($id, [
            'contain' => [],
        ]);

        $this->set('rector', $rector);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $rector = $this->Rectors->newEmptyEntity();
        if ($this->request->is('post')) {
            $rector = $this->Rectors->patchEntity($rector, $this->request->getData());
            if ($this->Rectors->save($rector)) {
                $this->Flash->success(__('The rector has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The rector could not be saved. Please, try again.'));
        }
        $this->set(compact('rector'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Rector id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $rector = $this->Rectors->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $rector = $this->Rectors->patchEntity($rector, $this->request->getData());
            if ($this->Rectors->save($rector)) {
                $this->Flash->success(__('The rector has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The rector could not be saved. Please, try again.'));
        }
        $this->set(compact('rector'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Rector id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $rector = $this->Rectors->get($id);
        if ($this->Rectors->delete($rector)) {
            $this->Flash->success(__('The rector has been deleted.'));
        } else {
            $this->Flash->error(__('The rector could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
