<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * Universitys Controller
 *
 * @property \App\Model\Table\UniversitysTable $Universitys
 * @method \App\Model\Entity\University[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class UniversitysController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $universitys = $this->paginate($this->Universitys);

        $this->set(compact('universitys'));
    }

    /**
     * View method
     *
     * @param string|null $id University id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $university = $this->Universitys->get($id, [
            'contain' => [],
        ]);

        $this->set('university', $university);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $university = $this->Universitys->newEmptyEntity();
        if ($this->request->is('post')) {
            $university = $this->Universitys->patchEntity($university, $this->request->getData());
            if ($this->Universitys->save($university)) {
                $this->Flash->success(__('The university has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The university could not be saved. Please, try again.'));
        }
        $this->set(compact('university'));
    }

    /**
     * Edit method
     *
     * @param string|null $id University id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $university = $this->Universitys->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $university = $this->Universitys->patchEntity($university, $this->request->getData());
            if ($this->Universitys->save($university)) {
                $this->Flash->success(__('The university has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The university could not be saved. Please, try again.'));
        }
        $this->set(compact('university'));
    }

    /**
     * Delete method
     *
     * @param string|null $id University id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $university = $this->Universitys->get($id);
        if ($this->Universitys->delete($university)) {
            $this->Flash->success(__('The university has been deleted.'));
        } else {
            $this->Flash->error(__('The university could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
