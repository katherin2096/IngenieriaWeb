<?php
declare(strict_types=1);

namespace App\Controller;

/**
 * DepartmentDirectors Controller
 *
 * @property \App\Model\Table\DepartmentDirectorsTable $DepartmentDirectors
 * @method \App\Model\Entity\DepartmentDirector[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class DepartmentDirectorsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null|void Renders view
     */
    public function index()
    {
        $departmentDirectors = $this->paginate($this->DepartmentDirectors);

        $this->set(compact('departmentDirectors'));
    }

    /**
     * View method
     *
     * @param string|null $id Department Director id.
     * @return \Cake\Http\Response|null|void Renders view
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $departmentDirector = $this->DepartmentDirectors->get($id, [
            'contain' => [],
        ]);

        $this->set('departmentDirector', $departmentDirector);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null|void Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $departmentDirector = $this->DepartmentDirectors->newEmptyEntity();
        if ($this->request->is('post')) {
            $departmentDirector = $this->DepartmentDirectors->patchEntity($departmentDirector, $this->request->getData());
            if ($this->DepartmentDirectors->save($departmentDirector)) {
                $this->Flash->success(__('The department director has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The department director could not be saved. Please, try again.'));
        }
        $this->set(compact('departmentDirector'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Department Director id.
     * @return \Cake\Http\Response|null|void Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $departmentDirector = $this->DepartmentDirectors->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $departmentDirector = $this->DepartmentDirectors->patchEntity($departmentDirector, $this->request->getData());
            if ($this->DepartmentDirectors->save($departmentDirector)) {
                $this->Flash->success(__('The department director has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The department director could not be saved. Please, try again.'));
        }
        $this->set(compact('departmentDirector'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Department Director id.
     * @return \Cake\Http\Response|null|void Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $departmentDirector = $this->DepartmentDirectors->get($id);
        if ($this->DepartmentDirectors->delete($departmentDirector)) {
            $this->Flash->success(__('The department director has been deleted.'));
        } else {
            $this->Flash->error(__('The department director could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
