<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\StudyPlan $studyPlan
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Study Plan'), ['action' => 'edit', $studyPlan->id_study_plan], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Study Plan'), ['action' => 'delete', $studyPlan->id_study_plan], ['confirm' => __('Are you sure you want to delete # {0}?', $studyPlan->id_study_plan), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Study Plans'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Study Plan'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="studyPlans view content">
            <h3><?= h($studyPlan->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($studyPlan->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Study Plan') ?></th>
                    <td><?= $this->Number->format($studyPlan->id_study_plan) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Academic') ?></th>
                    <td><?= $this->Number->format($studyPlan->id_academic) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($studyPlan->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($studyPlan->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $studyPlan->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
