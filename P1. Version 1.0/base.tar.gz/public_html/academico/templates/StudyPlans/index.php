<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\StudyPlan[]|\Cake\Collection\CollectionInterface $studyPlans
 */
?>
<div class="studyPlans index content">
    <?= $this->Html->link(__('New Study Plan'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Study Plans') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_study_plan') ?></th>
                    <th><?= $this->Paginator->sort('id_academic') ?></th>
                    <th><?= $this->Paginator->sort('name') ?></th>
                    <th><?= $this->Paginator->sort('estate') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($studyPlans as $studyPlan): ?>
                <tr>
                    <td><?= $this->Number->format($studyPlan->id_study_plan) ?></td>
                    <td><?= $this->Number->format($studyPlan->id_academic) ?></td>
                    <td><?= h($studyPlan->name) ?></td>
                    <td><?= h($studyPlan->estate) ?></td>
                    <td><?= h($studyPlan->created) ?></td>
                    <td><?= h($studyPlan->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $studyPlan->id_study_plan]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $studyPlan->id_study_plan]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $studyPlan->id_study_plan], ['confirm' => __('Are you sure you want to delete # {0}?', $studyPlan->id_study_plan)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
