<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Assignment $assignment
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Assignment'), ['action' => 'edit', $assignment->assignment_id], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Assignment'), ['action' => 'delete', $assignment->assignment_id], ['confirm' => __('Are you sure you want to delete # {0}?', $assignment->assignment_id), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Assignments'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Assignment'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="assignments view content">
            <h3><?= h($assignment->assignment_id) ?></h3>
            <table>
                <tr>
                    <th><?= __('Assignment Id') ?></th>
                    <td><?= $this->Number->format($assignment->assignment_id) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Section') ?></th>
                    <td><?= $this->Number->format($assignment->id_section) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Course') ?></th>
                    <td><?= $this->Number->format($assignment->id_course) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Shift') ?></th>
                    <td><?= $this->Number->format($assignment->id_shift) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Teacher') ?></th>
                    <td><?= $this->Number->format($assignment->id_teacher) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($assignment->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($assignment->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $assignment->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
