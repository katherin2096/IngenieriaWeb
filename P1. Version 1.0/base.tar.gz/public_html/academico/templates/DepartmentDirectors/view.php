<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\DepartmentDirector $departmentDirector
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Department Director'), ['action' => 'edit', $departmentDirector->id_department_director], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Department Director'), ['action' => 'delete', $departmentDirector->id_department_director], ['confirm' => __('Are you sure you want to delete # {0}?', $departmentDirector->id_department_director), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Department Directors'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Department Director'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="departmentDirectors view content">
            <h3><?= h($departmentDirector->id_department_director) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name Department Director') ?></th>
                    <td><?= h($departmentDirector->name_department_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname Department Director') ?></th>
                    <td><?= h($departmentDirector->lastname_department_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email Department Director') ?></th>
                    <td><?= h($departmentDirector->email_department_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone Department Director') ?></th>
                    <td><?= h($departmentDirector->phone_department_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Department Director') ?></th>
                    <td><?= $this->Number->format($departmentDirector->id_department_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Dni Department Director') ?></th>
                    <td><?= $this->Number->format($departmentDirector->dni_department_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Department') ?></th>
                    <td><?= $this->Number->format($departmentDirector->id_department) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($departmentDirector->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($departmentDirector->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $departmentDirector->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
