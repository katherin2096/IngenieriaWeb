<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\DepartmentDirector $departmentDirector
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Department Directors'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="departmentDirectors form content">
            <?= $this->Form->create($departmentDirector) ?>
            <fieldset>
                <legend><?= __('Add Department Director') ?></legend>
                <?php
                    echo $this->Form->control('dni_department_director');
                    echo $this->Form->control('id_department');
                    echo $this->Form->control('name_department_director');
                    echo $this->Form->control('lastname_department_director');
                    echo $this->Form->control('email_department_director');
                    echo $this->Form->control('phone_department_director');
                    echo $this->Form->control('estate');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
