<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\DepartmentDirector[]|\Cake\Collection\CollectionInterface $departmentDirectors
 */
?>
<div class="departmentDirectors index content">
    <?= $this->Html->link(__('New Department Director'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Department Directors') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_department_director') ?></th>
                    <th><?= $this->Paginator->sort('dni_department_director') ?></th>
                    <th><?= $this->Paginator->sort('id_department') ?></th>
                    <th><?= $this->Paginator->sort('name_department_director') ?></th>
                    <th><?= $this->Paginator->sort('lastname_department_director') ?></th>
                    <th><?= $this->Paginator->sort('email_department_director') ?></th>
                    <th><?= $this->Paginator->sort('phone_department_director') ?></th>
                    <th><?= $this->Paginator->sort('estate') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($departmentDirectors as $departmentDirector): ?>
                <tr>
                    <td><?= $this->Number->format($departmentDirector->id_department_director) ?></td>
                    <td><?= $this->Number->format($departmentDirector->dni_department_director) ?></td>
                    <td><?= $this->Number->format($departmentDirector->id_department) ?></td>
                    <td><?= h($departmentDirector->name_department_director) ?></td>
                    <td><?= h($departmentDirector->lastname_department_director) ?></td>
                    <td><?= h($departmentDirector->email_department_director) ?></td>
                    <td><?= h($departmentDirector->phone_department_director) ?></td>
                    <td><?= h($departmentDirector->estate) ?></td>
                    <td><?= h($departmentDirector->created) ?></td>
                    <td><?= h($departmentDirector->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $departmentDirector->id_department_director]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $departmentDirector->id_department_director]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $departmentDirector->id_department_director], ['confirm' => __('Are you sure you want to delete # {0}?', $departmentDirector->id_department_director)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
