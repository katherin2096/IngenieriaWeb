<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Department $department
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Department'), ['action' => 'edit', $department->id_department], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Department'), ['action' => 'delete', $department->id_department], ['confirm' => __('Are you sure you want to delete # {0}?', $department->id_department), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Departments'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Department'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="departments view content">
            <h3><?= h($department->id_department) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name Department') ?></th>
                    <td><?= h($department->name_department) ?></td>
                </tr>
                <tr>
                    <th><?= __('Anexo Department') ?></th>
                    <td><?= h($department->anexo_department) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Department') ?></th>
                    <td><?= $this->Number->format($department->id_department) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Faculty') ?></th>
                    <td><?= $this->Number->format($department->id_faculty) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($department->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($department->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $department->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
