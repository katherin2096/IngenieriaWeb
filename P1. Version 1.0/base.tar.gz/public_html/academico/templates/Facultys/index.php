<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Faculty[]|\Cake\Collection\CollectionInterface $facultys
 */
?>
<div class="facultys index content">
    <?= $this->Html->link(__('New Faculty'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Facultys') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_faculty') ?></th>
                    <th><?= $this->Paginator->sort('id_university') ?></th>
                    <th><?= $this->Paginator->sort('name_faculty') ?></th>
                    <th><?= $this->Paginator->sort('anexo_faculty') ?></th>
                    <th><?= $this->Paginator->sort('estate') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($facultys as $faculty): ?>
                <tr>
                    <td><?= $this->Number->format($faculty->id_faculty) ?></td>
                    <td><?= $this->Number->format($faculty->id_university) ?></td>
                    <td><?= h($faculty->name_faculty) ?></td>
                    <td><?= h($faculty->anexo_faculty) ?></td>
                    <td><?= h($faculty->estate) ?></td>
                    <td><?= h($faculty->created) ?></td>
                    <td><?= h($faculty->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $faculty->id_faculty]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $faculty->id_faculty]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $faculty->id_faculty], ['confirm' => __('Are you sure you want to delete # {0}?', $faculty->id_faculty)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
