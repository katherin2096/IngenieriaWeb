<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Faculty $faculty
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Facultys'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="facultys form content">
            <?= $this->Form->create($faculty) ?>
            <fieldset>
                <legend><?= __('Add Faculty') ?></legend>
                <?php
                    echo $this->Form->control('id_university');
                    echo $this->Form->control('name_faculty');
                    echo $this->Form->control('anexo_faculty');
                    echo $this->Form->control('estate');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
