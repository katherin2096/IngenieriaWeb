<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\SchoolCoordinator[]|\Cake\Collection\CollectionInterface $schoolCoordinators
 */
?>
<div class="schoolCoordinators index content">
    <?= $this->Html->link(__('New School Coordinator'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('School Coordinators') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_school_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('dni_school_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('id_school') ?></th>
                    <th><?= $this->Paginator->sort('name_school_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('lastname_school_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('email_school_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('phone_school_coordinator') ?></th>
                    <th><?= $this->Paginator->sort('estate') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($schoolCoordinators as $schoolCoordinator): ?>
                <tr>
                    <td><?= $this->Number->format($schoolCoordinator->id_school_coordinator) ?></td>
                    <td><?= $this->Number->format($schoolCoordinator->dni_school_coordinator) ?></td>
                    <td><?= $this->Number->format($schoolCoordinator->id_school) ?></td>
                    <td><?= h($schoolCoordinator->name_school_coordinator) ?></td>
                    <td><?= h($schoolCoordinator->lastname_school_coordinator) ?></td>
                    <td><?= h($schoolCoordinator->email_school_coordinator) ?></td>
                    <td><?= h($schoolCoordinator->phone_school_coordinator) ?></td>
                    <td><?= h($schoolCoordinator->estate) ?></td>
                    <td><?= h($schoolCoordinator->created) ?></td>
                    <td><?= h($schoolCoordinator->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $schoolCoordinator->id_school_coordinator]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $schoolCoordinator->id_school_coordinator]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $schoolCoordinator->id_school_coordinator], ['confirm' => __('Are you sure you want to delete # {0}?', $schoolCoordinator->id_school_coordinator)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
