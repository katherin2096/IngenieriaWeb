<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\SchoolCoordinator $schoolCoordinator
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $schoolCoordinator->id_school_coordinator],
                ['confirm' => __('Are you sure you want to delete # {0}?', $schoolCoordinator->id_school_coordinator), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List School Coordinators'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="schoolCoordinators form content">
            <?= $this->Form->create($schoolCoordinator) ?>
            <fieldset>
                <legend><?= __('Edit School Coordinator') ?></legend>
                <?php
                    echo $this->Form->control('dni_school_coordinator');
                    echo $this->Form->control('id_school');
                    echo $this->Form->control('name_school_coordinator');
                    echo $this->Form->control('lastname_school_coordinator');
                    echo $this->Form->control('email_school_coordinator');
                    echo $this->Form->control('phone_school_coordinator');
                    echo $this->Form->control('estate');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
