<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\SchoolCoordinator $schoolCoordinator
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit School Coordinator'), ['action' => 'edit', $schoolCoordinator->id_school_coordinator], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete School Coordinator'), ['action' => 'delete', $schoolCoordinator->id_school_coordinator], ['confirm' => __('Are you sure you want to delete # {0}?', $schoolCoordinator->id_school_coordinator), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List School Coordinators'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New School Coordinator'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="schoolCoordinators view content">
            <h3><?= h($schoolCoordinator->id_school_coordinator) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name School Coordinator') ?></th>
                    <td><?= h($schoolCoordinator->name_school_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname School Coordinator') ?></th>
                    <td><?= h($schoolCoordinator->lastname_school_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email School Coordinator') ?></th>
                    <td><?= h($schoolCoordinator->email_school_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone School Coordinator') ?></th>
                    <td><?= h($schoolCoordinator->phone_school_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id School Coordinator') ?></th>
                    <td><?= $this->Number->format($schoolCoordinator->id_school_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Dni School Coordinator') ?></th>
                    <td><?= $this->Number->format($schoolCoordinator->dni_school_coordinator) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id School') ?></th>
                    <td><?= $this->Number->format($schoolCoordinator->id_school) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($schoolCoordinator->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($schoolCoordinator->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $schoolCoordinator->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
