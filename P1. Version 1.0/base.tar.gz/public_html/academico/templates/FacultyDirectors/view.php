<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\FacultyDirector $facultyDirector
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Faculty Director'), ['action' => 'edit', $facultyDirector->id_faculty_director], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Faculty Director'), ['action' => 'delete', $facultyDirector->id_faculty_director], ['confirm' => __('Are you sure you want to delete # {0}?', $facultyDirector->id_faculty_director), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Faculty Directors'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Faculty Director'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="facultyDirectors view content">
            <h3><?= h($facultyDirector->id_faculty_director) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name Faculty Director') ?></th>
                    <td><?= h($facultyDirector->name_faculty_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname Faculty Director') ?></th>
                    <td><?= h($facultyDirector->lastname_faculty_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email Faculty Director') ?></th>
                    <td><?= h($facultyDirector->email_faculty_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone Faculty Director') ?></th>
                    <td><?= h($facultyDirector->phone_faculty_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Faculty Director') ?></th>
                    <td><?= $this->Number->format($facultyDirector->id_faculty_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Dni Faculty Director') ?></th>
                    <td><?= $this->Number->format($facultyDirector->dni_faculty_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Faculty') ?></th>
                    <td><?= $this->Number->format($facultyDirector->id_faculty) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($facultyDirector->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($facultyDirector->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $facultyDirector->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
