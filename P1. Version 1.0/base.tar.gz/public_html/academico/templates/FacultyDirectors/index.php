<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\FacultyDirector[]|\Cake\Collection\CollectionInterface $facultyDirectors
 */
?>
<div class="facultyDirectors index content">
    <?= $this->Html->link(__('New Faculty Director'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('Faculty Directors') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_faculty_director') ?></th>
                    <th><?= $this->Paginator->sort('dni_faculty_director') ?></th>
                    <th><?= $this->Paginator->sort('id_faculty') ?></th>
                    <th><?= $this->Paginator->sort('name_faculty_director') ?></th>
                    <th><?= $this->Paginator->sort('lastname_faculty_director') ?></th>
                    <th><?= $this->Paginator->sort('email_faculty_director') ?></th>
                    <th><?= $this->Paginator->sort('phone_faculty_director') ?></th>
                    <th><?= $this->Paginator->sort('estate') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($facultyDirectors as $facultyDirector): ?>
                <tr>
                    <td><?= $this->Number->format($facultyDirector->id_faculty_director) ?></td>
                    <td><?= $this->Number->format($facultyDirector->dni_faculty_director) ?></td>
                    <td><?= $this->Number->format($facultyDirector->id_faculty) ?></td>
                    <td><?= h($facultyDirector->name_faculty_director) ?></td>
                    <td><?= h($facultyDirector->lastname_faculty_director) ?></td>
                    <td><?= h($facultyDirector->email_faculty_director) ?></td>
                    <td><?= h($facultyDirector->phone_faculty_director) ?></td>
                    <td><?= h($facultyDirector->estate) ?></td>
                    <td><?= h($facultyDirector->created) ?></td>
                    <td><?= h($facultyDirector->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $facultyDirector->id_faculty_director]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $facultyDirector->id_faculty_director]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $facultyDirector->id_faculty_director], ['confirm' => __('Are you sure you want to delete # {0}?', $facultyDirector->id_faculty_director)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
