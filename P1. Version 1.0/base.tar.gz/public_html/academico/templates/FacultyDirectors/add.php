<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\FacultyDirector $facultyDirector
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('List Faculty Directors'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="facultyDirectors form content">
            <?= $this->Form->create($facultyDirector) ?>
            <fieldset>
                <legend><?= __('Add Faculty Director') ?></legend>
                <?php
                    echo $this->Form->control('dni_faculty_director');
                    echo $this->Form->control('id_faculty');
                    echo $this->Form->control('name_faculty_director');
                    echo $this->Form->control('lastname_faculty_director');
                    echo $this->Form->control('email_faculty_director');
                    echo $this->Form->control('phone_faculty_director');
                    echo $this->Form->control('estate');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
