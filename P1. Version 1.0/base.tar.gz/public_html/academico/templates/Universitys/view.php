<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\University $university
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit University'), ['action' => 'edit', $university->id_university], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete University'), ['action' => 'delete', $university->id_university], ['confirm' => __('Are you sure you want to delete # {0}?', $university->id_university), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Universitys'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New University'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="universitys view content">
            <h3><?= h($university->id_university) ?></h3>
            <table>
                <tr>
                    <th><?= __('Ruc University') ?></th>
                    <td><?= h($university->ruc_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Name University') ?></th>
                    <td><?= h($university->name_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Address University') ?></th>
                    <td><?= h($university->address_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Pagina Web') ?></th>
                    <td><?= h($university->pagina_web) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone University') ?></th>
                    <td><?= h($university->phone_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id University') ?></th>
                    <td><?= $this->Number->format($university->id_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($university->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($university->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $university->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
