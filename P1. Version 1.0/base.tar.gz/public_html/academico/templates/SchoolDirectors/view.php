<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\SchoolDirector $schoolDirector
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit School Director'), ['action' => 'edit', $schoolDirector->id_school_director], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete School Director'), ['action' => 'delete', $schoolDirector->id_school_director], ['confirm' => __('Are you sure you want to delete # {0}?', $schoolDirector->id_school_director), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List School Directors'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New School Director'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="schoolDirectors view content">
            <h3><?= h($schoolDirector->id_school_director) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name School Director') ?></th>
                    <td><?= h($schoolDirector->name_school_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname School Director') ?></th>
                    <td><?= h($schoolDirector->lastname_school_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email School Director') ?></th>
                    <td><?= h($schoolDirector->email_school_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone School Director') ?></th>
                    <td><?= h($schoolDirector->phone_school_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id School Director') ?></th>
                    <td><?= $this->Number->format($schoolDirector->id_school_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Dni School Director') ?></th>
                    <td><?= $this->Number->format($schoolDirector->dni_school_director) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id School') ?></th>
                    <td><?= $this->Number->format($schoolDirector->id_school) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($schoolDirector->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($schoolDirector->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate School Director') ?></th>
                    <td><?= $schoolDirector->estate_school_director ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
