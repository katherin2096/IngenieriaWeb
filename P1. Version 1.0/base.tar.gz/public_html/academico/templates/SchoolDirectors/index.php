<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\SchoolDirector[]|\Cake\Collection\CollectionInterface $schoolDirectors
 */
?>
<div class="schoolDirectors index content">
    <?= $this->Html->link(__('New School Director'), ['action' => 'add'], ['class' => 'button float-right']) ?>
    <h3><?= __('School Directors') ?></h3>
    <div class="table-responsive">
        <table>
            <thead>
                <tr>
                    <th><?= $this->Paginator->sort('id_school_director') ?></th>
                    <th><?= $this->Paginator->sort('dni_school_director') ?></th>
                    <th><?= $this->Paginator->sort('id_school') ?></th>
                    <th><?= $this->Paginator->sort('name_school_director') ?></th>
                    <th><?= $this->Paginator->sort('lastname_school_director') ?></th>
                    <th><?= $this->Paginator->sort('email_school_director') ?></th>
                    <th><?= $this->Paginator->sort('phone_school_director') ?></th>
                    <th><?= $this->Paginator->sort('estate_school_director') ?></th>
                    <th><?= $this->Paginator->sort('created') ?></th>
                    <th><?= $this->Paginator->sort('modified') ?></th>
                    <th class="actions"><?= __('Actions') ?></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($schoolDirectors as $schoolDirector): ?>
                <tr>
                    <td><?= $this->Number->format($schoolDirector->id_school_director) ?></td>
                    <td><?= $this->Number->format($schoolDirector->dni_school_director) ?></td>
                    <td><?= $this->Number->format($schoolDirector->id_school) ?></td>
                    <td><?= h($schoolDirector->name_school_director) ?></td>
                    <td><?= h($schoolDirector->lastname_school_director) ?></td>
                    <td><?= h($schoolDirector->email_school_director) ?></td>
                    <td><?= h($schoolDirector->phone_school_director) ?></td>
                    <td><?= h($schoolDirector->estate_school_director) ?></td>
                    <td><?= h($schoolDirector->created) ?></td>
                    <td><?= h($schoolDirector->modified) ?></td>
                    <td class="actions">
                        <?= $this->Html->link(__('View'), ['action' => 'view', $schoolDirector->id_school_director]) ?>
                        <?= $this->Html->link(__('Edit'), ['action' => 'edit', $schoolDirector->id_school_director]) ?>
                        <?= $this->Form->postLink(__('Delete'), ['action' => 'delete', $schoolDirector->id_school_director], ['confirm' => __('Are you sure you want to delete # {0}?', $schoolDirector->id_school_director)]) ?>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <div class="paginator">
        <ul class="pagination">
            <?= $this->Paginator->first('<< ' . __('first')) ?>
            <?= $this->Paginator->prev('< ' . __('previous')) ?>
            <?= $this->Paginator->numbers() ?>
            <?= $this->Paginator->next(__('next') . ' >') ?>
            <?= $this->Paginator->last(__('last') . ' >>') ?>
        </ul>
        <p><?= $this->Paginator->counter(__('Page {{page}} of {{pages}}, showing {{current}} record(s) out of {{count}} total')) ?></p>
    </div>
</div>
