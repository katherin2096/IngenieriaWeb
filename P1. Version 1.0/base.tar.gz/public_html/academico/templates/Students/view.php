<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Student $student
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Student'), ['action' => 'edit', $student->id_student], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Student'), ['action' => 'delete', $student->id_student], ['confirm' => __('Are you sure you want to delete # {0}?', $student->id_student), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Students'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Student'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="students view content">
            <h3><?= h($student->id_student) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name Student') ?></th>
                    <td><?= h($student->name_student) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname Student') ?></th>
                    <td><?= h($student->lastname_student) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email Student') ?></th>
                    <td><?= h($student->email_student) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone Student') ?></th>
                    <td><?= h($student->phone_student) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Student') ?></th>
                    <td><?= $this->Number->format($student->id_student) ?></td>
                </tr>
                <tr>
                    <th><?= __('Dni Student') ?></th>
                    <td><?= $this->Number->format($student->dni_student) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id School') ?></th>
                    <td><?= $this->Number->format($student->id_school) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($student->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($student->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $student->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
