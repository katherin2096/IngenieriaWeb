<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Shift $shift
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Shift'), ['action' => 'edit', $shift->id_shift], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Shift'), ['action' => 'delete', $shift->id_shift], ['confirm' => __('Are you sure you want to delete # {0}?', $shift->id_shift), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Shifts'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Shift'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="shifts view content">
            <h3><?= h($shift->name) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name') ?></th>
                    <td><?= h($shift->name) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Shift') ?></th>
                    <td><?= $this->Number->format($shift->id_shift) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($shift->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($shift->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
