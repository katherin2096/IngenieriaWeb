<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Dean $dean
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Dean'), ['action' => 'edit', $dean->id_dean], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Dean'), ['action' => 'delete', $dean->id_dean], ['confirm' => __('Are you sure you want to delete # {0}?', $dean->id_dean), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Deans'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Dean'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="deans view content">
            <h3><?= h($dean->id_dean) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name Dean') ?></th>
                    <td><?= h($dean->name_dean) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname Dean') ?></th>
                    <td><?= h($dean->lastname_dean) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email Dean') ?></th>
                    <td><?= h($dean->email_dean) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone Dean') ?></th>
                    <td><?= h($dean->phone_dean) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Dean') ?></th>
                    <td><?= $this->Number->format($dean->id_dean) ?></td>
                </tr>
                <tr>
                    <th><?= __('Dni Dean') ?></th>
                    <td><?= $this->Number->format($dean->dni_dean) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Faculty') ?></th>
                    <td><?= $this->Number->format($dean->id_faculty) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($dean->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($dean->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $dean->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
