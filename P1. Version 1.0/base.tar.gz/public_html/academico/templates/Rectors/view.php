<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Rector $rector
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Rector'), ['action' => 'edit', $rector->id_rector], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Rector'), ['action' => 'delete', $rector->id_rector], ['confirm' => __('Are you sure you want to delete # {0}?', $rector->id_rector), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Rectors'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Rector'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="rectors view content">
            <h3><?= h($rector->id_rector) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name Rector') ?></th>
                    <td><?= h($rector->name_rector) ?></td>
                </tr>
                <tr>
                    <th><?= __('Lastname Rector') ?></th>
                    <td><?= h($rector->lastname_rector) ?></td>
                </tr>
                <tr>
                    <th><?= __('Email Rector') ?></th>
                    <td><?= h($rector->email_rector) ?></td>
                </tr>
                <tr>
                    <th><?= __('Phone Rector') ?></th>
                    <td><?= h($rector->phone_rector) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Rector') ?></th>
                    <td><?= $this->Number->format($rector->id_rector) ?></td>
                </tr>
                <tr>
                    <th><?= __('Dni Rector') ?></th>
                    <td><?= $this->Number->format($rector->dni_rector) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id University') ?></th>
                    <td><?= $this->Number->format($rector->id_university) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($rector->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($rector->modified) ?></td>
                </tr>
                <tr>
                    <th><?= __('Estate') ?></th>
                    <td><?= $rector->estate ? __('Yes') : __('No'); ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
