<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\TypeContract $typeContract
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $typeContract->id_type_contract],
                ['confirm' => __('Are you sure you want to delete # {0}?', $typeContract->id_type_contract), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Type Contracts'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="typeContracts form content">
            <?= $this->Form->create($typeContract) ?>
            <fieldset>
                <legend><?= __('Edit Type Contract') ?></legend>
                <?php
                    echo $this->Form->control('name_type_contract');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
