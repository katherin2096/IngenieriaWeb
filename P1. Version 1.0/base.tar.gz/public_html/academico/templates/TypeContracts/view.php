<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\TypeContract $typeContract
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Html->link(__('Edit Type Contract'), ['action' => 'edit', $typeContract->id_type_contract], ['class' => 'side-nav-item']) ?>
            <?= $this->Form->postLink(__('Delete Type Contract'), ['action' => 'delete', $typeContract->id_type_contract], ['confirm' => __('Are you sure you want to delete # {0}?', $typeContract->id_type_contract), 'class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('List Type Contracts'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
            <?= $this->Html->link(__('New Type Contract'), ['action' => 'add'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="typeContracts view content">
            <h3><?= h($typeContract->id_type_contract) ?></h3>
            <table>
                <tr>
                    <th><?= __('Name Type Contract') ?></th>
                    <td><?= h($typeContract->name_type_contract) ?></td>
                </tr>
                <tr>
                    <th><?= __('Id Type Contract') ?></th>
                    <td><?= $this->Number->format($typeContract->id_type_contract) ?></td>
                </tr>
                <tr>
                    <th><?= __('Created') ?></th>
                    <td><?= h($typeContract->created) ?></td>
                </tr>
                <tr>
                    <th><?= __('Modified') ?></th>
                    <td><?= h($typeContract->modified) ?></td>
                </tr>
            </table>
        </div>
    </div>
</div>
