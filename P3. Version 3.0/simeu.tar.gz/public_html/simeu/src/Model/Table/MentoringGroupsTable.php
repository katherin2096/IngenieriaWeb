<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * MentoringGroups Model
 *
 * @method \App\Model\Entity\MentoringGroup get($primaryKey, $options = [])
 * @method \App\Model\Entity\MentoringGroup newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\MentoringGroup[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\MentoringGroup|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MentoringGroup saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\MentoringGroup patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\MentoringGroup[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\MentoringGroup findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class MentoringGroupsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('mentoring_groups');
        $this->setDisplayField('id_mentoring_group');
        $this->setPrimaryKey('id_mentoring_group');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_mentoring_group')
            ->allowEmptyString('id_mentoring_group', null, 'create');

        $validator
            ->integer('id_mentor')
            ->requirePresence('id_mentor', 'create')
            ->notEmptyString('id_mentor');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
