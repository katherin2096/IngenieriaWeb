<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Keepers Model
 *
 * @method \App\Model\Entity\Keeper get($primaryKey, $options = [])
 * @method \App\Model\Entity\Keeper newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Keeper[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Keeper|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Keeper saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Keeper patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Keeper[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Keeper findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class KeepersTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('keepers');
        $this->setDisplayField('id_keeper');
        $this->setPrimaryKey('id_keeper');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_keeper')
            ->allowEmptyString('id_keeper', null, 'create');

        $validator
            ->integer('id_school')
            ->requirePresence('id_school', 'create')
            ->notEmptyString('id_school');

        $validator
            ->integer('dni_keeper')
            ->requirePresence('dni_keeper', 'create')
            ->notEmptyString('dni_keeper')
            ->add('dni_keeper', 'unique', ['rule' => 'validateUnique', 'provider' => 'table']);

        $validator
            ->scalar('name_keeper')
            ->maxLength('name_keeper', 255)
            ->requirePresence('name_keeper', 'create')
            ->notEmptyString('name_keeper');

        $validator
            ->scalar('phone_keeper')
            ->maxLength('phone_keeper', 15)
            ->requirePresence('phone_keeper', 'create')
            ->notEmptyString('phone_keeper');

        $validator
            ->integer('id_student')
            ->allowEmptyString('id_student');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        $validator
            ->integer('id_user')
            ->allowEmptyString('id_user');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules)
    {
        $rules->add($rules->isUnique(['dni_keeper']));

        return $rules;
    }
}
