<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * SessionMentoring Model
 *
 * @method \App\Model\Entity\SessionMentoring get($primaryKey, $options = [])
 * @method \App\Model\Entity\SessionMentoring newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\SessionMentoring[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\SessionMentoring|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SessionMentoring saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\SessionMentoring patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\SessionMentoring[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\SessionMentoring findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class SessionMentoringTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('session_mentoring');
        $this->setDisplayField('id_session');
        $this->setPrimaryKey('id_session');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_session')
            ->allowEmptyString('id_session', null, 'create');

        $validator
            ->integer('id_mentoring_group')
            ->requirePresence('id_mentoring_group', 'create')
            ->notEmptyString('id_mentoring_group');

        $validator
            ->dateTime('hour_and_date')
            ->requirePresence('hour_and_date', 'create')
            ->notEmptyDateTime('hour_and_date');

        $validator
            ->time('duration_session')
            ->requirePresence('duration_session', 'create')
            ->notEmptyTime('duration_session');

        $validator
            ->integer('id_enviroment')
            ->requirePresence('id_enviroment', 'create')
            ->notEmptyString('id_enviroment');

        $validator
            ->scalar('classroom_session')
            ->maxLength('classroom_session', 255)
            ->allowEmptyString('classroom_session');

        $validator
            ->boolean('succesful')
            ->notEmptyString('succesful');

        return $validator;
    }
}
