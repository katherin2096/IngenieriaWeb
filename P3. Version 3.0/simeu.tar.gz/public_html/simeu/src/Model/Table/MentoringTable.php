<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Mentoring Model
 *
 * @method \App\Model\Entity\Mentoring get($primaryKey, $options = [])
 * @method \App\Model\Entity\Mentoring newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Mentoring[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Mentoring|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Mentoring saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Mentoring patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Mentoring[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Mentoring findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class MentoringTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('mentoring');
        $this->setDisplayField('id_mentoring');
        $this->setPrimaryKey('id_mentoring');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_mentoring')
            ->allowEmptyString('id_mentoring', null, 'create');

        $validator
            ->integer('id_academic')
            ->requirePresence('id_academic', 'create')
            ->notEmptyString('id_academic');

        $validator
            ->integer('id_keeper')
            ->requirePresence('id_keeper', 'create')
            ->notEmptyString('id_keeper');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
