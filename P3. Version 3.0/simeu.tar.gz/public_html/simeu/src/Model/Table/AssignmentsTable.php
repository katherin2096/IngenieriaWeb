<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Assignments Model
 *
 * @method \App\Model\Entity\Assignment get($primaryKey, $options = [])
 * @method \App\Model\Entity\Assignment newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Assignment[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Assignment|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Assignment saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Assignment patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Assignment[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Assignment findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class AssignmentsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('assignments');
        $this->setDisplayField('assignment_id');
        $this->setPrimaryKey('assignment_id');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('assignment_id')
            ->allowEmptyString('assignment_id', null, 'create');

        $validator
            ->integer('id_section')
            ->requirePresence('id_section', 'create')
            ->notEmptyString('id_section');

        $validator
            ->integer('id_course')
            ->requirePresence('id_course', 'create')
            ->notEmptyString('id_course');

        $validator
            ->integer('id_shift')
            ->requirePresence('id_shift', 'create')
            ->notEmptyString('id_shift');

        $validator
            ->integer('id_teacher')
            ->requirePresence('id_teacher', 'create')
            ->notEmptyString('id_teacher');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
