<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Pupils Model
 *
 * @method \App\Model\Entity\Pupil get($primaryKey, $options = [])
 * @method \App\Model\Entity\Pupil newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Pupil[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Pupil|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Pupil saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Pupil patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Pupil[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Pupil findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class PupilsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('pupils');
        $this->setDisplayField('id_pupil');
        $this->setPrimaryKey('id_pupil');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_pupil')
            ->allowEmptyString('id_pupil', null, 'create');

        $validator
            ->integer('id_mentoring_group')
            ->requirePresence('id_mentoring_group', 'create')
            ->notEmptyString('id_mentoring_group');

        $validator
            ->integer('id_student')
            ->allowEmptyString('id_student');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
