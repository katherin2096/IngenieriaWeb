<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * StudyPlans Model
 *
 * @method \App\Model\Entity\StudyPlan get($primaryKey, $options = [])
 * @method \App\Model\Entity\StudyPlan newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\StudyPlan[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\StudyPlan|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StudyPlan saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\StudyPlan patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\StudyPlan[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\StudyPlan findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class StudyPlansTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('study_plans');
        $this->setDisplayField('id_study_plan');
        $this->setPrimaryKey('id_study_plan');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_study_plan')
            ->allowEmptyString('id_study_plan', null, 'create');

        $validator
            ->integer('id_academic')
            ->requirePresence('id_academic', 'create')
            ->notEmptyString('id_academic');

        $validator
            ->scalar('name_study_plans')
            ->maxLength('name_study_plans', 255)
            ->requirePresence('name_study_plans', 'create')
            ->notEmptyString('name_study_plans');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
