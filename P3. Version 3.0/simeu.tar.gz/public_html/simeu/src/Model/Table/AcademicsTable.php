<?php
namespace App\Model\Table;

use Cake\ORM\Query;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Academics Model
 *
 * @method \App\Model\Entity\Academic get($primaryKey, $options = [])
 * @method \App\Model\Entity\Academic newEntity($data = null, array $options = [])
 * @method \App\Model\Entity\Academic[] newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Academic|false save(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Academic saveOrFail(\Cake\Datasource\EntityInterface $entity, $options = [])
 * @method \App\Model\Entity\Academic patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method \App\Model\Entity\Academic[] patchEntities($entities, array $data, array $options = [])
 * @method \App\Model\Entity\Academic findOrCreate($search, callable $callback = null, $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class AcademicsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config)
    {
        parent::initialize($config);

        $this->setTable('academics');
        $this->setDisplayField('name');
        $this->setPrimaryKey('id_academic');

        $this->addBehavior('Timestamp');
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator)
    {
        $validator
            ->integer('id_academic')
            ->allowEmptyString('id_academic', null, 'create');

        $validator
            ->integer('id_school')
            ->requirePresence('id_school', 'create')
            ->notEmptyString('id_school');

        $validator
            ->integer('id_department_director')
            ->requirePresence('id_department_director', 'create')
            ->notEmptyString('id_department_director');

        $validator
            ->integer('id_school_coordinator')
            ->requirePresence('id_school_coordinator', 'create')
            ->notEmptyString('id_school_coordinator');

        $validator
            ->scalar('name')
            ->maxLength('name', 255)
            ->requirePresence('name', 'create')
            ->notEmptyString('name');

        $validator
            ->boolean('estate')
            ->notEmptyString('estate');

        return $validator;
    }
}
