<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Mentor Entity
 *
 * @property int $id_mentor
 * @property int $id_mentoring
 * @property int|null $id_student
 * @property bool $estate
 * @property int|null $id_user
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 */
class Mentor extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_mentoring' => true,
        'id_student' => true,
        'estate' => true,
        'id_user' => true,
        'created' => true,
        'modified' => true,
    ];
}
