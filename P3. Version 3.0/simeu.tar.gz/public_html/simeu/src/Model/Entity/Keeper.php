<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Keeper Entity
 *
 * @property int $id_keeper
 * @property int $id_school
 * @property int $dni_keeper
 * @property string $name_keeper
 * @property string $phone_keeper
 * @property int|null $id_student
 * @property bool $estate
 * @property int|null $id_user
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 */
class Keeper extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_school' => true,
        'dni_keeper' => true,
        'name_keeper' => true,
        'phone_keeper' => true,
        'id_student' => true,
        'estate' => true,
        'id_user' => true,
        'created' => true,
        'modified' => true,
    ];
}
