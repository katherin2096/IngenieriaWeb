<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * SessionMentoring Entity
 *
 * @property int $id_session
 * @property int $id_mentoring_group
 * @property \Cake\I18n\FrozenTime $hour_and_date
 * @property \Cake\I18n\FrozenTime $duration_session
 * @property int $id_enviroment
 * @property string|null $classroom_session
 * @property bool $succesful
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 */
class SessionMentoring extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'id_mentoring_group' => true,
        'hour_and_date' => true,
        'duration_session' => true,
        'id_enviroment' => true,
        'classroom_session' => true,
        'succesful' => true,
        'created' => true,
        'modified' => true,
    ];
}
