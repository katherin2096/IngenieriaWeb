<?php
namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Rector Entity
 *
 * @property int $id_rector
 * @property int $dni_rector
 * @property int $id_university
 * @property string $name_rector
 * @property string $lastname_rector
 * @property string $phone_rector
 * @property bool $estate
 * @property int|null $id_user
 * @property \Cake\I18n\FrozenTime|null $created
 * @property \Cake\I18n\FrozenTime|null $modified
 */
class Rector extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array
     */
    protected $_accessible = [
        'dni_rector' => true,
        'id_university' => true,
        'name_rector' => true,
        'lastname_rector' => true,
        'phone_rector' => true,
        'estate' => true,
        'id_user' => true,
        'created' => true,
        'modified' => true,
    ];
}
