<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Enviroments Controller
 *
 * @property \App\Model\Table\EnviromentsTable $Enviroments
 *
 * @method \App\Model\Entity\Enviroment[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class EnviromentsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $enviroments = $this->paginate($this->Enviroments);

        $this->set(compact('enviroments'));
    }

    /**
     * View method
     *
     * @param string|null $id Enviroment id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $enviroment = $this->Enviroments->get($id, [
            'contain' => [],
        ]);

        $this->set('enviroment', $enviroment);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $enviroment = $this->Enviroments->newEntity();
        if ($this->request->is('post')) {
            $enviroment = $this->Enviroments->patchEntity($enviroment, $this->request->getData());
            if ($this->Enviroments->save($enviroment)) {
                $this->Flash->success(__('The enviroment has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The enviroment could not be saved. Please, try again.'));
        }
        $this->set(compact('enviroment'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Enviroment id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $enviroment = $this->Enviroments->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $enviroment = $this->Enviroments->patchEntity($enviroment, $this->request->getData());
            if ($this->Enviroments->save($enviroment)) {
                $this->Flash->success(__('The enviroment has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The enviroment could not be saved. Please, try again.'));
        }
        $this->set(compact('enviroment'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Enviroment id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $enviroment = $this->Enviroments->get($id);
        if ($this->Enviroments->delete($enviroment)) {
            $this->Flash->success(__('The enviroment has been deleted.'));
        } else {
            $this->Flash->error(__('The enviroment could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
