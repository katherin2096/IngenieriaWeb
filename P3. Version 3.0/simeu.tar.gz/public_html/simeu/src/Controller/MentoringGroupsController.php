<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * MentoringGroups Controller
 *
 * @property \App\Model\Table\MentoringGroupsTable $MentoringGroups
 *
 * @method \App\Model\Entity\MentoringGroup[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MentoringGroupsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['logout']);
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $mentoringGroups = $this->paginate($this->MentoringGroups);

        $this->set(compact('mentoringGroups'));
    }

    /**
     * View method
     *
     * @param string|null $id Mentoring Group id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $mentoringGroup = $this->MentoringGroups->get($id, [
            'contain' => [],
        ]);

        $this->set('mentoringGroup', $mentoringGroup);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $mentoringGroup = $this->MentoringGroups->newEntity();
        if ($this->request->is('post')) {
            $mentoringGroup = $this->MentoringGroups->patchEntity($mentoringGroup, $this->request->getData());
            if ($this->MentoringGroups->save($mentoringGroup)) {
                $this->Flash->success(__('The mentoring group has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The mentoring group could not be saved. Please, try again.'));
        }
        $this->set(compact('mentoringGroup'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Mentoring Group id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $mentoringGroup = $this->MentoringGroups->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $mentoringGroup = $this->MentoringGroups->patchEntity($mentoringGroup, $this->request->getData());
            if ($this->MentoringGroups->save($mentoringGroup)) {
                $this->Flash->success(__('The mentoring group has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The mentoring group could not be saved. Please, try again.'));
        }
        $this->set(compact('mentoringGroup'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Mentoring Group id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $mentoringGroup = $this->MentoringGroups->get($id);
        if ($this->MentoringGroups->delete($mentoringGroup)) {
            $this->Flash->success(__('The mentoring group has been deleted.'));
        } else {
            $this->Flash->error(__('The mentoring group could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    public function isAuthorized($user)
    {
        // By default deny access.
        if(isset($user['id_rol'])and $user['id_rol']==3)
        {
            if (in_array($this->request->action,['view','add','edit','logout']))
            {
                return true;
            }
        }
        elseif(isset($user['id_rol'])and $user['id_rol']==2)
        {
            if (in_array($this->request->action,['view','logout']))
            {
                return true;
            }
        }
        return parent::isAuthorized($user);
    }
}
