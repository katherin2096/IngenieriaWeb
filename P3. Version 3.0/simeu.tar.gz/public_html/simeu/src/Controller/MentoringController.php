<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Mentoring Controller
 *
 * @property \App\Model\Table\MentoringTable $Mentoring
 *
 * @method \App\Model\Entity\Mentoring[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class MentoringController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['logout']);
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $mentoring = $this->paginate($this->Mentoring);

        $this->set(compact('mentoring'));
    }

    /**
     * View method
     *
     * @param string|null $id Mentoring id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $mentoring = $this->Mentoring->get($id, [
            'contain' => [],
        ]);

        $this->set('mentoring', $mentoring);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $mentoring = $this->Mentoring->newEntity();
        if ($this->request->is('post')) {
            $mentoring = $this->Mentoring->patchEntity($mentoring, $this->request->getData());
            if ($this->Mentoring->save($mentoring)) {
                $this->Flash->success(__('The mentoring has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The mentoring could not be saved. Please, try again.'));
        }
        $this->set(compact('mentoring'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Mentoring id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $mentoring = $this->Mentoring->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $mentoring = $this->Mentoring->patchEntity($mentoring, $this->request->getData());
            if ($this->Mentoring->save($mentoring)) {
                $this->Flash->success(__('The mentoring has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The mentoring could not be saved. Please, try again.'));
        }
        $this->set(compact('mentoring'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Mentoring id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $mentoring = $this->Mentoring->get($id);
        if ($this->Mentoring->delete($mentoring)) {
            $this->Flash->success(__('The mentoring has been deleted.'));
        } else {
            $this->Flash->error(__('The mentoring could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    public function isAuthorized($user)
    {
        // By default deny access.
        if(isset($user['id_rol'])and $user['id_rol']==3)
        {
            if (in_array($this->request->action,['view','logout']))
            {
                return true;
            }
        }
        elseif(isset($user['id_rol'])and $user['id_rol']==2)
        {
            if (in_array($this->request->action,['view','logout']))
            {
                return true;
            }
        }
        return parent::isAuthorized($user);
    }
}
