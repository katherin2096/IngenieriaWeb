<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * TypeContracts Controller
 *
 * @property \App\Model\Table\TypeContractsTable $TypeContracts
 *
 * @method \App\Model\Entity\TypeContract[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class TypeContractsController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $typeContracts = $this->paginate($this->TypeContracts);

        $this->set(compact('typeContracts'));
    }

    /**
     * View method
     *
     * @param string|null $id Type Contract id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $typeContract = $this->TypeContracts->get($id, [
            'contain' => [],
        ]);

        $this->set('typeContract', $typeContract);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $typeContract = $this->TypeContracts->newEntity();
        if ($this->request->is('post')) {
            $typeContract = $this->TypeContracts->patchEntity($typeContract, $this->request->getData());
            if ($this->TypeContracts->save($typeContract)) {
                $this->Flash->success(__('The type contract has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The type contract could not be saved. Please, try again.'));
        }
        $this->set(compact('typeContract'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Type Contract id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $typeContract = $this->TypeContracts->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $typeContract = $this->TypeContracts->patchEntity($typeContract, $this->request->getData());
            if ($this->TypeContracts->save($typeContract)) {
                $this->Flash->success(__('The type contract has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The type contract could not be saved. Please, try again.'));
        }
        $this->set(compact('typeContract'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Type Contract id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $typeContract = $this->TypeContracts->get($id);
        if ($this->TypeContracts->delete($typeContract)) {
            $this->Flash->success(__('The type contract has been deleted.'));
        } else {
            $this->Flash->error(__('The type contract could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
