<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * SessionMentoring Controller
 *
 * @property \App\Model\Table\SessionMentoringTable $SessionMentoring
 *
 * @method \App\Model\Entity\SessionMentoring[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class SessionMentoringController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['logout']);
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $sessionMentoring = $this->paginate($this->SessionMentoring);

        $this->set(compact('sessionMentoring'));
    }

    /**
     * View method
     *
     * @param string|null $id Session Mentoring id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $sessionMentoring = $this->SessionMentoring->get($id, [
            'contain' => [],
        ]);

        $this->set('sessionMentoring', $sessionMentoring);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $sessionMentoring = $this->SessionMentoring->newEntity();
        if ($this->request->is('post')) {
            $sessionMentoring = $this->SessionMentoring->patchEntity($sessionMentoring, $this->request->getData());
            if ($this->SessionMentoring->save($sessionMentoring)) {
                $this->Flash->success(__('The session mentoring has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The session mentoring could not be saved. Please, try again.'));
        }
        $this->set(compact('sessionMentoring'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Session Mentoring id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $sessionMentoring = $this->SessionMentoring->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $sessionMentoring = $this->SessionMentoring->patchEntity($sessionMentoring, $this->request->getData());
            if ($this->SessionMentoring->save($sessionMentoring)) {
                $this->Flash->success(__('The session mentoring has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The session mentoring could not be saved. Please, try again.'));
        }
        $this->set(compact('sessionMentoring'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Session Mentoring id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $sessionMentoring = $this->SessionMentoring->get($id);
        if ($this->SessionMentoring->delete($sessionMentoring)) {
            $this->Flash->success(__('The session mentoring has been deleted.'));
        } else {
            $this->Flash->error(__('The session mentoring could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
    public function isAuthorized($user)
    {
        // By default deny access.
        if(isset($user['id_rol'])and $user['id_rol']==3)
        {
            if (in_array($this->request->action,['view','add','delete','logout']))
            {
                return true;
            }
        }
        elseif(isset($user['id_rol'])and $user['id_rol']==2)
        {
            if (in_array($this->request->action,['view','add','edit','logout']))
            {
                return true;
            }
        }
        return parent::isAuthorized($user);
    }
}
