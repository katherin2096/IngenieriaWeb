<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Pupils Controller
 *
 * @property \App\Model\Table\PupilsTable $Pupils
 *
 * @method \App\Model\Entity\Pupil[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class PupilsController extends AppController
{
    public function initialize()
    {
        parent::initialize();
        $this->Auth->allow(['logout']);
    }
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $pupils = $this->paginate($this->Pupils);

        $this->set(compact('pupils'));
    }

    /**
     * View method
     *
     * @param string|null $id Pupil id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $pupil = $this->Pupils->get($id, [
            'contain' => [],
        ]);

        $this->set('pupil', $pupil);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $pupil = $this->Pupils->newEntity();
        if ($this->request->is('post')) {
            $pupil = $this->Pupils->patchEntity($pupil, $this->request->getData());
            if ($this->Pupils->save($pupil)) {
                $this->Flash->success(__('The pupil has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The pupil could not be saved. Please, try again.'));
        }
        $this->set(compact('pupil'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Pupil id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $pupil = $this->Pupils->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $pupil = $this->Pupils->patchEntity($pupil, $this->request->getData());
            if ($this->Pupils->save($pupil)) {
                $this->Flash->success(__('The pupil has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The pupil could not be saved. Please, try again.'));
        }
        $this->set(compact('pupil'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Pupil id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $pupil = $this->Pupils->get($id);
        if ($this->Pupils->delete($pupil)) {
            $this->Flash->success(__('The pupil has been deleted.'));
        } else {
            $this->Flash->error(__('The pupil could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }

    public function isAuthorized($user)
    {
        // By default deny access.
        if(isset($user['id_rol'])and $user['id_rol']==3)
        {
            if (in_array($this->request->action,['view','add','logout']))
            {
                return true;
            }
        }
        elseif(isset($user['id_rol'])and $user['id_rol']==2)
        {
            if (in_array($this->request->action,['view','logout']))
            {
                return true;
            }
        }
        return parent::isAuthorized($user);
    }
}
