<?php
namespace App\Controller;

use App\Controller\AppController;

/**
 * Keepers Controller
 *
 * @property \App\Model\Table\KeepersTable $Keepers
 *
 * @method \App\Model\Entity\Keeper[]|\Cake\Datasource\ResultSetInterface paginate($object = null, array $settings = [])
 */
class KeepersController extends AppController
{
    /**
     * Index method
     *
     * @return \Cake\Http\Response|null
     */
    public function index()
    {
        $keepers = $this->paginate($this->Keepers);

        $this->set(compact('keepers'));
    }

    /**
     * View method
     *
     * @param string|null $id Keeper id.
     * @return \Cake\Http\Response|null
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function view($id = null)
    {
        $keeper = $this->Keepers->get($id, [
            'contain' => [],
        ]);

        $this->set('keeper', $keeper);
    }

    /**
     * Add method
     *
     * @return \Cake\Http\Response|null Redirects on successful add, renders view otherwise.
     */
    public function add()
    {
        $keeper = $this->Keepers->newEntity();
        if ($this->request->is('post')) {
            $keeper = $this->Keepers->patchEntity($keeper, $this->request->getData());
            if ($this->Keepers->save($keeper)) {
                $this->Flash->success(__('The keeper has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The keeper could not be saved. Please, try again.'));
        }
        $this->set(compact('keeper'));
    }

    /**
     * Edit method
     *
     * @param string|null $id Keeper id.
     * @return \Cake\Http\Response|null Redirects on successful edit, renders view otherwise.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function edit($id = null)
    {
        $keeper = $this->Keepers->get($id, [
            'contain' => [],
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
            $keeper = $this->Keepers->patchEntity($keeper, $this->request->getData());
            if ($this->Keepers->save($keeper)) {
                $this->Flash->success(__('The keeper has been saved.'));

                return $this->redirect(['action' => 'index']);
            }
            $this->Flash->error(__('The keeper could not be saved. Please, try again.'));
        }
        $this->set(compact('keeper'));
    }

    /**
     * Delete method
     *
     * @param string|null $id Keeper id.
     * @return \Cake\Http\Response|null Redirects to index.
     * @throws \Cake\Datasource\Exception\RecordNotFoundException When record not found.
     */
    public function delete($id = null)
    {
        $this->request->allowMethod(['post', 'delete']);
        $keeper = $this->Keepers->get($id);
        if ($this->Keepers->delete($keeper)) {
            $this->Flash->success(__('The keeper has been deleted.'));
        } else {
            $this->Flash->error(__('The keeper could not be deleted. Please, try again.'));
        }

        return $this->redirect(['action' => 'index']);
    }
}
