<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DeansFixture
 */
class DeansFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_dean' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de decano', 'autoIncrement' => true, 'precision' => null],
        'dni_dean' => ['type' => 'integer', 'length' => 8, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar numero de dni', 'precision' => null, 'autoIncrement' => null],
        'id_faculty' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null, 'autoIncrement' => null],
        'name_dean' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar nombre de Decano', 'precision' => null, 'fixed' => null],
        'lastname_dean' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar apellidos de Decano', 'precision' => null, 'fixed' => null],
        'phone_dean' => ['type' => 'string', 'length' => 15, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar celular de Decano, porfavor omita el codigo de pais', 'precision' => null, 'fixed' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'id_user' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'id user', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'user_key' => ['type' => 'index', 'columns' => ['id_user'], 'length' => []],
            'faculty_key' => ['type' => 'index', 'columns' => ['id_faculty'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_dean'], 'length' => []],
            'dni_dean' => ['type' => 'unique', 'columns' => ['dni_dean'], 'length' => []],
            'deans_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'deans_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_faculty'], 'references' => ['faculties', 'id_faculty'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_dean' => 1,
                'dni_dean' => 1,
                'id_faculty' => 1,
                'name_dean' => 'Lorem ipsum dolor sit amet',
                'lastname_dean' => 'Lorem ipsum dolor sit amet',
                'phone_dean' => 'Lorem ipsum d',
                'estate' => 1,
                'id_user' => 1,
                'created' => '2020-05-27 09:45:58',
                'modified' => '2020-05-27 09:45:58',
            ],
        ];
        parent::init();
    }
}
