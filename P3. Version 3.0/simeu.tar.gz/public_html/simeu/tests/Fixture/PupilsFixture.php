<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * PupilsFixture
 */
class PupilsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_pupil' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de mentoriado ', 'autoIncrement' => true, 'precision' => null],
        'id_mentoring_group' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de grupo de mentoria', 'precision' => null, 'autoIncrement' => null],
        'id_student' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'Ingresar codigo del estudiante', 'precision' => null, 'autoIncrement' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'mentoring_group_key' => ['type' => 'index', 'columns' => ['id_mentoring_group'], 'length' => []],
            'student_key' => ['type' => 'index', 'columns' => ['id_student'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_pupil'], 'length' => []],
            'pupils_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_mentoring_group'], 'references' => ['mentoring_groups', 'id_mentoring_group'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'pupils_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_student'], 'references' => ['students', 'id_student'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_pupil' => 1,
                'id_mentoring_group' => 1,
                'id_student' => 1,
                'estate' => 1,
                'created' => '2020-05-27 09:46:16',
                'modified' => '2020-05-27 09:46:16',
            ],
        ];
        parent::init();
    }
}
