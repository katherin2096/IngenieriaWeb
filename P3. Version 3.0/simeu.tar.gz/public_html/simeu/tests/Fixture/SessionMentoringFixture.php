<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * SessionMentoringFixture
 */
class SessionMentoringFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'session_mentoring';
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_session' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de sesion ', 'autoIncrement' => true, 'precision' => null],
        'id_mentoring_group' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de grupo de mentoria', 'precision' => null, 'autoIncrement' => null],
        'hour_and_date' => ['type' => 'datetime', 'length' => null, 'null' => false, 'default' => null, 'comment' => 'fecha y hora de la sesion', 'precision' => null],
        'duration_session' => ['type' => 'time', 'length' => null, 'null' => false, 'default' => null, 'comment' => '', 'precision' => null],
        'id_enviroment' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'ambiente en el que se desarrolla la sesion', 'precision' => null, 'autoIncrement' => null],
        'classroom_session' => ['type' => 'string', 'length' => 255, 'null' => true, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'aula de mentoria opcional', 'precision' => null, 'fixed' => null],
        'succesful' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'mentoring_group_key' => ['type' => 'index', 'columns' => ['id_mentoring_group'], 'length' => []],
            'enviroment_key' => ['type' => 'index', 'columns' => ['id_enviroment'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_session'], 'length' => []],
            'session_mentoring_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_mentoring_group'], 'references' => ['mentoring_groups', 'id_mentoring_group'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'session_mentoring_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_enviroment'], 'references' => ['enviroments', 'id_enviroment'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_session' => 1,
                'id_mentoring_group' => 1,
                'hour_and_date' => '2020-05-27 09:47:15',
                'duration_session' => '09:47:15',
                'id_enviroment' => 1,
                'classroom_session' => 'Lorem ipsum dolor sit amet',
                'succesful' => 1,
                'created' => '2020-05-27 09:47:15',
                'modified' => '2020-05-27 09:47:15',
            ],
        ];
        parent::init();
    }
}
