<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * DepartmentsFixture
 */
class DepartmentsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_department' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de departamento', 'autoIncrement' => true, 'precision' => null],
        'id_faculty' => ['type' => 'integer', 'length' => 50, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de facultad', 'precision' => null, 'autoIncrement' => null],
        'name_department' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar nombre de departamento', 'precision' => null, 'fixed' => null],
        'anexo_department' => ['type' => 'string', 'length' => 5, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar el anexo para comunicarse con el departamento', 'precision' => null, 'fixed' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'faculty_key' => ['type' => 'index', 'columns' => ['id_faculty'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_department'], 'length' => []],
            'name_department' => ['type' => 'unique', 'columns' => ['name_department'], 'length' => []],
            'departments_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_faculty'], 'references' => ['faculties', 'id_faculty'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_department' => 1,
                'id_faculty' => 1,
                'name_department' => 'Lorem ipsum dolor sit amet',
                'anexo_department' => 'Lor',
                'estate' => 1,
                'created' => '2020-05-27 09:45:59',
                'modified' => '2020-05-27 09:45:59',
            ],
        ];
        parent::init();
    }
}
