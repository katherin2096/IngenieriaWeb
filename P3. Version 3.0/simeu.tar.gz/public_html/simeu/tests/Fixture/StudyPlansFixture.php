<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * StudyPlansFixture
 */
class StudyPlansFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_study_plan' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de plan de estudio', 'autoIncrement' => true, 'precision' => null],
        'id_academic' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de de periodo academico', 'precision' => null, 'autoIncrement' => null],
        'name_study_plans' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar codigo de semestre ejemplo 2016', 'precision' => null, 'fixed' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '0', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'academic_key' => ['type' => 'index', 'columns' => ['id_academic'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_study_plan'], 'length' => []],
            'study_plans_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_academic'], 'references' => ['academics', 'id_academic'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_study_plan' => 1,
                'id_academic' => 1,
                'name_study_plans' => 'Lorem ipsum dolor sit amet',
                'estate' => 1,
                'created' => '2020-05-27 09:46:04',
                'modified' => '2020-05-27 09:46:04',
            ],
        ];
        parent::init();
    }
}
