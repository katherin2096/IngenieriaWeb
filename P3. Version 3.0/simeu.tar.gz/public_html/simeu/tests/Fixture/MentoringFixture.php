<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * MentoringFixture
 */
class MentoringFixture extends TestFixture
{
    /**
     * Table name
     *
     * @var string
     */
    public $table = 'mentoring';
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_mentoring' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de mentoria', 'autoIncrement' => true, 'precision' => null],
        'id_academic' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de periodo academico', 'precision' => null, 'autoIncrement' => null],
        'id_keeper' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar codigo del encargado', 'precision' => null, 'autoIncrement' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'keeper_key' => ['type' => 'index', 'columns' => ['id_keeper'], 'length' => []],
            'academic_key' => ['type' => 'index', 'columns' => ['id_academic'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_mentoring'], 'length' => []],
            'mentoring_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_keeper'], 'references' => ['keepers', 'id_keeper'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'mentoring_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_academic'], 'references' => ['academics', 'id_academic'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_mentoring' => 1,
                'id_academic' => 1,
                'id_keeper' => 1,
                'estate' => 1,
                'created' => '2020-05-27 09:46:13',
                'modified' => '2020-05-27 09:46:13',
            ],
        ];
        parent::init();
    }
}
