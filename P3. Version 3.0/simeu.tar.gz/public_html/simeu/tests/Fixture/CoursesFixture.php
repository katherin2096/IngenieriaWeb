<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * CoursesFixture
 */
class CoursesFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_course' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de curso', 'autoIncrement' => true, 'precision' => null],
        'id_semester' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de semestre', 'precision' => null, 'autoIncrement' => null],
        'id_type' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de tipo de curso: obligatorio, etc', 'precision' => null, 'autoIncrement' => null],
        'name' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar nombre de curso', 'precision' => null, 'fixed' => null],
        'hours' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar duracion en horas del curso', 'precision' => null, 'autoIncrement' => null],
        'credit' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar cantidad de creditaje del curso', 'precision' => null, 'autoIncrement' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => 'Estado del curso, activo o inactivo', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'semester_id' => ['type' => 'index', 'columns' => ['id_semester'], 'length' => []],
            'type_id' => ['type' => 'index', 'columns' => ['id_type'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_course'], 'length' => []],
            'courses_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_semester'], 'references' => ['semesters', 'id_semester'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'courses_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_type'], 'references' => ['types', 'id_type'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_course' => 1,
                'id_semester' => 1,
                'id_type' => 1,
                'name' => 'Lorem ipsum dolor sit amet',
                'hours' => 1,
                'credit' => 1,
                'estate' => 1,
                'created' => '2020-05-27 09:46:07',
                'modified' => '2020-05-27 09:46:07',
            ],
        ];
        parent::init();
    }
}
