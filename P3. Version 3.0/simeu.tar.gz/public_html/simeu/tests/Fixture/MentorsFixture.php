<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * MentorsFixture
 */
class MentorsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_mentor' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de mentor ', 'autoIncrement' => true, 'precision' => null],
        'id_mentoring' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de mentoria', 'precision' => null, 'autoIncrement' => null],
        'id_student' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'Ingresar codigo del estudiante', 'precision' => null, 'autoIncrement' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'id_user' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'id user', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'user_key' => ['type' => 'index', 'columns' => ['id_user'], 'length' => []],
            'mentoring_key' => ['type' => 'index', 'columns' => ['id_mentoring'], 'length' => []],
            'student_key' => ['type' => 'index', 'columns' => ['id_student'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_mentor'], 'length' => []],
            'mentors_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'mentors_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_mentoring'], 'references' => ['mentoring', 'id_mentoring'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'mentors_ibfk_3' => ['type' => 'foreign', 'columns' => ['id_student'], 'references' => ['students', 'id_student'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_mentor' => 1,
                'id_mentoring' => 1,
                'id_student' => 1,
                'estate' => 1,
                'id_user' => 1,
                'created' => '2020-05-27 09:46:14',
                'modified' => '2020-05-27 09:46:14',
            ],
        ];
        parent::init();
    }
}
