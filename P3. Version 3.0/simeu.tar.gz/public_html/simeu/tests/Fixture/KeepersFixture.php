<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * KeepersFixture
 */
class KeepersFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_keeper' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Codigo de encargado mentoria', 'autoIncrement' => true, 'precision' => null],
        'id_school' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de carrera a la que esta asignado', 'precision' => null, 'autoIncrement' => null],
        'dni_keeper' => ['type' => 'integer', 'length' => 8, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'dni de encargado', 'precision' => null, 'autoIncrement' => null],
        'name_keeper' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar nombre de encargado mentoria', 'precision' => null, 'fixed' => null],
        'phone_keeper' => ['type' => 'string', 'length' => 15, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Celular de encargado de mentoria', 'precision' => null, 'fixed' => null],
        'id_student' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'Ingresar codigo del encargado', 'precision' => null, 'autoIncrement' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'id_user' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'id user', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'user_key' => ['type' => 'index', 'columns' => ['id_user'], 'length' => []],
            'school_key' => ['type' => 'index', 'columns' => ['id_school'], 'length' => []],
            'student_key' => ['type' => 'index', 'columns' => ['id_student'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_keeper'], 'length' => []],
            'dni_keeper' => ['type' => 'unique', 'columns' => ['dni_keeper'], 'length' => []],
            'keepers_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'keepers_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_school'], 'references' => ['schools', 'id_school'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'keepers_ibfk_3' => ['type' => 'foreign', 'columns' => ['id_student'], 'references' => ['students', 'id_student'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_keeper' => 1,
                'id_school' => 1,
                'dni_keeper' => 1,
                'name_keeper' => 'Lorem ipsum dolor sit amet',
                'phone_keeper' => 'Lorem ipsum d',
                'id_student' => 1,
                'estate' => 1,
                'id_user' => 1,
                'created' => '2020-05-27 09:46:12',
                'modified' => '2020-05-27 09:46:12',
            ],
        ];
        parent::init();
    }
}
