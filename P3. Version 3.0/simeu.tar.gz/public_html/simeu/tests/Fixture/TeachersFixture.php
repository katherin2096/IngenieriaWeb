<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * TeachersFixture
 */
class TeachersFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_teacher' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'codigo docente', 'autoIncrement' => true, 'precision' => null],
        'dni_teacher' => ['type' => 'integer', 'length' => 8, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'Ingresar numero de dni', 'precision' => null, 'autoIncrement' => null],
        'id_type_contract' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'tipo de contrato', 'precision' => null, 'autoIncrement' => null],
        'name_teacher' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar nombre de Docente', 'precision' => null, 'fixed' => null],
        'lastname_teacher' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar apellidos de Docente', 'precision' => null, 'fixed' => null],
        'phone_teacher' => ['type' => 'string', 'length' => 15, 'null' => false, 'default' => null, 'collate' => 'utf8mb4_general_ci', 'comment' => 'Ingresar celular de Docente, porfavor omita el codigo de pais', 'precision' => null, 'fixed' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'id_user' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => true, 'default' => null, 'comment' => 'id user', 'precision' => null, 'autoIncrement' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'user_key' => ['type' => 'index', 'columns' => ['id_user'], 'length' => []],
            'contact_key' => ['type' => 'index', 'columns' => ['id_type_contract'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_teacher'], 'length' => []],
            'dni_teacher' => ['type' => 'unique', 'columns' => ['dni_teacher'], 'length' => []],
            'teachers_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_user'], 'references' => ['users', 'id_user'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'teachers_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_type_contract'], 'references' => ['type_contracts', 'id_type_contract'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'utf8mb4_general_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_teacher' => 1,
                'dni_teacher' => 1,
                'id_type_contract' => 1,
                'name_teacher' => 'Lorem ipsum dolor sit amet',
                'lastname_teacher' => 'Lorem ipsum dolor sit amet',
                'phone_teacher' => 'Lorem ipsum d',
                'estate' => 1,
                'id_user' => 1,
                'created' => '2020-05-27 09:46:08',
                'modified' => '2020-05-27 09:46:08',
            ],
        ];
        parent::init();
    }
}
