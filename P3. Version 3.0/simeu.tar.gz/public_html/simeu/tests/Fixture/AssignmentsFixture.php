<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * AssignmentsFixture
 */
class AssignmentsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'assignment_id' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => '', 'autoIncrement' => true, 'precision' => null],
        'id_section' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de seccion o grupo de curso', 'precision' => null, 'autoIncrement' => null],
        'id_course' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de curso', 'precision' => null, 'autoIncrement' => null],
        'id_shift' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de turno', 'precision' => null, 'autoIncrement' => null],
        'id_teacher' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de docente', 'precision' => null, 'autoIncrement' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'section_id' => ['type' => 'index', 'columns' => ['id_section'], 'length' => []],
            'course_id' => ['type' => 'index', 'columns' => ['id_course'], 'length' => []],
            'shift_id' => ['type' => 'index', 'columns' => ['id_shift'], 'length' => []],
            'teacher_id' => ['type' => 'index', 'columns' => ['id_teacher'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['assignment_id'], 'length' => []],
            'assignments_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_section'], 'references' => ['sections', 'id_section'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'assignments_ibfk_2' => ['type' => 'foreign', 'columns' => ['id_course'], 'references' => ['courses', 'id_course'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'assignments_ibfk_3' => ['type' => 'foreign', 'columns' => ['id_shift'], 'references' => ['shifts', 'id_shift'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
            'assignments_ibfk_4' => ['type' => 'foreign', 'columns' => ['id_teacher'], 'references' => ['teachers', 'id_teacher'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'assignment_id' => 1,
                'id_section' => 1,
                'id_course' => 1,
                'id_shift' => 1,
                'id_teacher' => 1,
                'estate' => 1,
                'created' => '2020-05-27 09:46:10',
                'modified' => '2020-05-27 09:46:10',
            ],
        ];
        parent::init();
    }
}
