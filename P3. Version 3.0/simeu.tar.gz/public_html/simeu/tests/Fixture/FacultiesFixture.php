<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * FacultiesFixture
 */
class FacultiesFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_faculty' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de facultad', 'autoIncrement' => true, 'precision' => null],
        'id_university' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id (RUC) de universidad', 'precision' => null, 'autoIncrement' => null],
        'name_faculty' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar nombre de facultad', 'precision' => null, 'fixed' => null],
        'anexo_faculty' => ['type' => 'string', 'length' => 5, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar el anexo para comunicarse con la facultad', 'precision' => null, 'fixed' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'university_key' => ['type' => 'index', 'columns' => ['id_university'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_faculty'], 'length' => []],
            'name_faculty' => ['type' => 'unique', 'columns' => ['name_faculty'], 'length' => []],
            'faculties_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_university'], 'references' => ['universities', 'id_university'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_faculty' => 1,
                'id_university' => 1,
                'name_faculty' => 'Lorem ipsum dolor sit amet',
                'anexo_faculty' => 'Lor',
                'estate' => 1,
                'created' => '2020-05-27 09:45:57',
                'modified' => '2020-05-27 09:45:57',
            ],
        ];
        parent::init();
    }
}
