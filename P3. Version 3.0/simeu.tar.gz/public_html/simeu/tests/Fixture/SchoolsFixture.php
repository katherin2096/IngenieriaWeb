<?php
namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * SchoolsFixture
 */
class SchoolsFixture extends TestFixture
{
    /**
     * Fields
     *
     * @var array
     */
    // @codingStandardsIgnoreStart
    public $fields = [
        'id_school' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de escuela', 'autoIncrement' => true, 'precision' => null],
        'id_department' => ['type' => 'integer', 'length' => 11, 'unsigned' => false, 'null' => false, 'default' => null, 'comment' => 'id de departamento', 'precision' => null, 'autoIncrement' => null],
        'name_school' => ['type' => 'string', 'length' => 255, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar nombre de escuela', 'precision' => null, 'fixed' => null],
        'anexo' => ['type' => 'string', 'length' => 5, 'null' => false, 'default' => null, 'collate' => 'latin1_swedish_ci', 'comment' => 'Ingresar el anexo para comunicarse con la escuela', 'precision' => null, 'fixed' => null],
        'estate' => ['type' => 'boolean', 'length' => null, 'null' => false, 'default' => '1', 'comment' => '', 'precision' => null],
        'created' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        'modified' => ['type' => 'datetime', 'length' => null, 'null' => true, 'default' => null, 'comment' => '', 'precision' => null],
        '_indexes' => [
            'department_key' => ['type' => 'index', 'columns' => ['id_department'], 'length' => []],
        ],
        '_constraints' => [
            'primary' => ['type' => 'primary', 'columns' => ['id_school'], 'length' => []],
            'name_school' => ['type' => 'unique', 'columns' => ['name_school'], 'length' => []],
            'schools_ibfk_1' => ['type' => 'foreign', 'columns' => ['id_department'], 'references' => ['departments', 'id_department'], 'update' => 'restrict', 'delete' => 'restrict', 'length' => []],
        ],
        '_options' => [
            'engine' => 'InnoDB',
            'collation' => 'latin1_swedish_ci'
        ],
    ];
    // @codingStandardsIgnoreEnd
    /**
     * Init method
     *
     * @return void
     */
    public function init()
    {
        $this->records = [
            [
                'id_school' => 1,
                'id_department' => 1,
                'name_school' => 'Lorem ipsum dolor sit amet',
                'anexo' => 'Lor',
                'estate' => 1,
                'created' => '2020-05-27 09:46:01',
                'modified' => '2020-05-27 09:46:01',
            ],
        ];
        parent::init();
    }
}
