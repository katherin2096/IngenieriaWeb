<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\MentoringTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\MentoringTable Test Case
 */
class MentoringTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\MentoringTable
     */
    public $Mentoring;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.Mentoring',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('Mentoring') ? [] : ['className' => MentoringTable::class];
        $this->Mentoring = TableRegistry::getTableLocator()->get('Mentoring', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->Mentoring);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
