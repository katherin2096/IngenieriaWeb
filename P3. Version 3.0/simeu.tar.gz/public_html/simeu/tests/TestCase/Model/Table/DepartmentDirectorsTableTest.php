<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\DepartmentDirectorsTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\DepartmentDirectorsTable Test Case
 */
class DepartmentDirectorsTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\DepartmentDirectorsTable
     */
    public $DepartmentDirectors;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.DepartmentDirectors',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('DepartmentDirectors') ? [] : ['className' => DepartmentDirectorsTable::class];
        $this->DepartmentDirectors = TableRegistry::getTableLocator()->get('DepartmentDirectors', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->DepartmentDirectors);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
