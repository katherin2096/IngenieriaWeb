<?php
namespace App\Test\TestCase\Model\Table;

use App\Model\Table\SessionMentoringTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\SessionMentoringTable Test Case
 */
class SessionMentoringTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\SessionMentoringTable
     */
    public $SessionMentoring;

    /**
     * Fixtures
     *
     * @var array
     */
    public $fixtures = [
        'app.SessionMentoring',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp()
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('SessionMentoring') ? [] : ['className' => SessionMentoringTable::class];
        $this->SessionMentoring = TableRegistry::getTableLocator()->get('SessionMentoring', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown()
    {
        unset($this->SessionMentoring);

        parent::tearDown();
    }

    /**
     * Test initialize method
     *
     * @return void
     */
    public function testInitialize()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault()
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
